
import React, { useState, useEffect } from "react";
import { TroubleShootingGuide } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Bot,
  Wrench,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowRight,
  ArrowLeft,
  Home,
  Crown,
  HelpCircle,
  MessageSquare,
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils"; // Corrected Path
import { useUser } from "@/components/hooks/useUser"; // Corrected Path
import { SupportTicket } from "@/api/entities";
import { format } from "date-fns";

export default function TroubleShooting() {
  const [guides, setGuides] = useState([]);
  const [selectedGuide, setSelectedGuide] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [conversationHistory, setConversationHistory] = useState([]);

  // Updated useUser hook call to destructure isLoading as isUserLoading
  const { user, isLoading: isUserLoading } = useUser();

  useEffect(() => {
    loadGuides();
  }, []);

  // New useEffect hook for redirection based on subscription status
  useEffect(() => {
    // Only redirect if user loading is complete and user is not premium
    if (!isUserLoading && user && user.subscription_status !== 'active') {
      window.location.href = createPageUrl("Subscription");
    }
  }, [user, isUserLoading]); // Depend on user and isUserLoading to trigger when they change

  const loadGuides = async () => {
    try {
      const allGuides = await TroubleShootingGuide.list();
      setGuides(allGuides);
    } catch (error) {
      console.error("Error loading guides:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAISearch = async () => {
    if (!searchQuery.trim()) return;

    setIsLoadingAI(true);
    try {
      const prompt = `You are a home service AI assistant. A customer is asking: "${searchQuery}". 
      
      Provide a helpful response that:
      1. Acknowledges their issue
      2. Provides 2-3 simple troubleshooting steps they can safely try
      3. Mentions when they should call a professional
      4. Is friendly and reassuring
      
      Keep it concise and practical.`;

      const response = await InvokeLLM({ prompt });

      // Track conversation history
      const newEntry = {
        question: searchQuery,
        answer: response,
        timestamp: new Date().toISOString()
      };
      setConversationHistory(prev => [...prev, newEntry]);

      setAiResponse(response);
    } catch (error) {
      console.error("AI search error:", error);
      setAiResponse("I'm sorry, I'm having trouble connecting right now. Please try again or contact our support team.");
    } finally {
      setIsLoadingAI(false);
    }
  };

  const startGuide = (guide) => {
    setSelectedGuide(guide);
    setCurrentStep(0);
    setAiResponse("");
    setSearchQuery(""); // Clear search query when starting a guide
  };

  const nextStep = () => {
    if (selectedGuide && currentStep < selectedGuide.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const resetGuide = () => {
    setSelectedGuide(null);
    setCurrentStep(0);
  };

  const submitToSupport = async () => {
    if (!user) {
      alert("Please log in to submit a support ticket.");
      return;
    }

    try {
      const conversationText = conversationHistory.map(entry =>
        `Customer: ${entry.question}\nAI Assistant: ${entry.answer}\n---\n`
      ).join('\n');

      await SupportTicket.create({
        customer_id: user.id,
        ai_conversation: conversationText,
        issue_summary: searchQuery,
        created_from: "ai_chat"
      });

      // Reset conversation
      setConversationHistory([]);
      setSearchQuery("");
      setAiResponse("");

      alert("Your conversation has been submitted to our support team! We'll get back to you within 24 hours.");
    } catch (error) {
      console.error("Error submitting to support:", error);
      alert("Failed to submit to support. Please try again later.");
    }
  };

  const filteredGuides = guides.filter(guide =>
    guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    guide.issue_keywords.some(keyword =>
      keyword.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  // Show loading spinner for both guide data and user data
  if (isLoading || isUserLoading) {
    return (
      <div className="p-6 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-16 bg-gray-200 rounded-xl"></div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="h-32 bg-gray-200 rounded-xl"></div>
            <div className="h-32 bg-gray-200 rounded-xl"></div>
            <div className="h-32 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Bot className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">AI Troubleshooting</h1>
          </div>
          <p className="text-lg text-gray-600">
            Try to solve common issues yourself with our step-by-step guides and AI assistant
          </p>
        </div>

        {/* AI Search */}
        <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-green-600" />
              Ask Our AI Assistant
              {user?.subscription_status === 'active' && (
                <Badge className="bg-purple-100 text-purple-800 ml-2">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium Feature
                </Badge>
              )}
            </CardTitle>
            {user?.subscription_status !== 'active' && (
              <p className="text-sm text-gray-500">
                Get unlimited AI assistance with a <Link to={createPageUrl("Subscription")} className="text-blue-600 hover:underline">Premium subscription</Link>
              </p>
            )}
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Describe your issue... (e.g., 'My faucet is leaking')"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAISearch()}
                  className="text-lg"
                />
              </div>
              <Button
                onClick={handleAISearch}
                disabled={isLoadingAI || !searchQuery.trim()}
                className="bg-green-600 hover:bg-green-700"
              >
                {isLoadingAI ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                ) : (
                  <Search className="w-4 h-4 mr-2" />
                )}
                Ask AI
              </Button>
            </div>

            {aiResponse && (
              <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Bot className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-green-800 mb-2">AI Assistant Response:</h4>
                    <p className="text-green-700 leading-relaxed whitespace-pre-line">{aiResponse}</p>
                  </div>
                </div>

                {/* Still Having Trouble Section */}
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4" />
                    Still having trouble?
                  </h4>

                  {user?.subscription_status === 'active' ? (
                    <div className="space-y-3">
                      <p className="text-blue-700 text-sm">
                        As a Premium subscriber, you can submit this conversation to our expert support team for personalized help!
                      </p>
                      <Button
                        onClick={submitToSupport}
                        className="bg-blue-600 hover:bg-blue-700"
                        size="sm"
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Get Human Support
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-blue-700 text-sm">
                        Get personalized help from our expert support team by upgrading to Premium!
                      </p>
                      <div className="flex gap-2">
                        <Link to={createPageUrl("Subscription")}>
                          <Button className="bg-purple-600 hover:bg-purple-700" size="sm">
                            <Crown className="w-4 h-4 mr-2" />
                            Upgrade to Premium
                          </Button>
                        </Link>
                        <Link to={createPageUrl("Jobs?action=new")}>
                          <Button variant="outline" size="sm">
                            <Wrench className="w-4 h-4 mr-2" />
                            Book Service Instead
                          </Button>
                        </Link>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Conversation History for Premium Users */}
        {user?.subscription_status === 'active' && conversationHistory.length > 0 && (
          <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-600" />
                Your AI Conversation History
                <Badge className="bg-purple-100 text-purple-800">
                  Premium Only
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-64 overflow-y-auto">
                {conversationHistory.map((entry, index) => (
                  <div key={index} className="border-l-4 border-purple-200 pl-4">
                    <p className="font-medium text-gray-900 mb-1">Q: {entry.question}</p>
                    <p className="text-gray-600 text-sm">{entry.answer}</p>
                    <p className="text-xs text-gray-400 mt-1">
                      {format(new Date(entry.timestamp), "MMM d, h:mm a")}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {selectedGuide ? (
          /* Step-by-Step Guide */
          <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl font-bold text-gray-900">{selectedGuide.title}</CardTitle>
                  <div className="flex items-center gap-4 mt-2">
                    <Badge className="bg-blue-100 text-blue-800">
                      Step {currentStep + 1} of {selectedGuide.steps.length}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <Clock className="w-3 h-3 mr-1" />
                      {selectedGuide.estimated_time_minutes} min
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {selectedGuide.difficulty_level}
                    </Badge>
                  </div>
                </div>
                <Button variant="outline" onClick={resetGuide}>
                  <Home className="w-4 h-4 mr-2" />
                  Back to Guides
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {selectedGuide.safety_warnings && selectedGuide.safety_warnings.length > 0 && currentStep === 0 && (
                <Alert className="mb-6 border-orange-200 bg-orange-50">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <AlertDescription className="text-orange-800">
                    <strong>Safety First:</strong> {selectedGuide.safety_warnings.join(' ')}
                  </AlertDescription>
                </Alert>
              )}

              {selectedGuide.tools_needed && selectedGuide.tools_needed.length > 0 && currentStep === 0 && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Wrench className="w-4 h-4" />
                    Tools You'll Need:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedGuide.tools_needed.map((tool, index) => (
                      <Badge key={index} variant="outline">{tool}</Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-6">
                {selectedGuide.steps[currentStep] && (
                  <div className="text-center">
                    <div className="text-6xl font-bold text-blue-600 mb-4">
                      {currentStep + 1}
                    </div>
                    <div className="max-w-2xl mx-auto">
                      <p className="text-lg text-gray-800 leading-relaxed mb-4">
                        {selectedGuide.steps[currentStep].instruction}
                      </p>

                      {selectedGuide.steps[currentStep].warning && (
                        <Alert className="mb-4 border-red-200 bg-red-50">
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                          <AlertDescription className="text-red-800">
                            <strong>Warning:</strong> {selectedGuide.steps[currentStep].warning}
                          </AlertDescription>
                        </Alert>
                      )}

                      {selectedGuide.steps[currentStep].image_url && (
                        <img
                          src={selectedGuide.steps[currentStep].image_url}
                          alt={`Step ${currentStep + 1}`}
                          className="mx-auto rounded-lg shadow-lg max-w-md w-full"
                        />
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Still Having Trouble Section in Guides */}
              {currentStep === selectedGuide.steps.length - 1 && (
                <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-semibold text-yellow-800 mb-2 flex items-center gap-2">
                    <HelpCircle className="w-4 h-4" />
                    Guide didn't solve your problem?
                  </h4>

                  {user?.subscription_status === 'active' ? (
                    <div className="space-y-3">
                      <p className="text-yellow-700 text-sm">
                        As a Premium subscriber, you can submit this troubleshooting attempt to our expert support team for advanced help!
                      </p>
                      <Button
                        onClick={async () => {
                          if (!user) {
                            alert("Please log in to submit a support ticket.");
                            return;
                          }
                          try {
                            await SupportTicket.create({
                              customer_id: user.id,
                              ai_conversation: `Attempted troubleshooting guide: ${selectedGuide.title}\nSteps completed: ${currentStep + 1}/${selectedGuide.steps.length}`,
                              issue_summary: selectedGuide.title,
                              troubleshooting_guide_id: selectedGuide.id,
                              created_from: "troubleshooting_guide"
                            });
                            alert("Your troubleshooting attempt has been submitted to support!");
                            resetGuide();
                          } catch (error) {
                            console.error("Error submitting guide to support:", error);
                            alert("Failed to submit to support. Please try again later.");
                          }
                        }}
                        className="bg-yellow-600 hover:bg-yellow-700"
                        size="sm"
                      >
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Get Expert Help
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-yellow-700 text-sm">
                        Get expert troubleshooting support with a Premium subscription!
                      </p>
                      <Link to={createPageUrl("Subscription")}>
                        <Button className="bg-purple-600 hover:bg-purple-700" size="sm">
                          <Crown className="w-4 h-4 mr-2" />
                          Upgrade for Expert Support
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
                <Button
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 0}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>

                <div className="flex items-center gap-2">
                  {selectedGuide.steps.map((_, index) => (
                    <div
                      key={index}
                      className={`w-3 h-3 rounded-full ${
                        index === currentStep ? 'bg-blue-600' :
                        index < currentStep ? 'bg-green-500' : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>

                {currentStep < selectedGuide.steps.length - 1 ? (
                  <Button onClick={nextStep} className="bg-blue-600 hover:bg-blue-700">
                    Next
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button className="bg-green-600 hover:bg-green-700" onClick={resetGuide}>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Complete
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          /* Guide Selection */
          <>
            {/* Search Results */}
            {searchQuery && filteredGuides.length > 0 && (
              <Card className="bg-white/60 backdrop-blur border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Search Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredGuides.map((guide) => (
                      <div
                        key={guide.id}
                        className="p-4 border border-gray-200 rounded-lg cursor-pointer hover:border-blue-300 hover:bg-blue-50 transition-colors"
                        onClick={() => startGuide(guide)}
                      >
                        <h3 className="font-semibold text-gray-900 mb-2">{guide.title}</h3>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="text-xs">{guide.service_type}</Badge>
                          <Badge variant="outline" className="text-xs">{guide.difficulty_level}</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {guide.estimated_time_minutes} minutes
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Popular Guides */}
            <Card className="bg-white/60 backdrop-blur border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Popular Troubleshooting Guides</CardTitle>
                <p className="text-gray-600">Try these common fixes before calling for service</p>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {guides.slice(0, 6).map((guide) => (
                    <div
                      key={guide.id}
                      className="p-6 border border-gray-200 rounded-xl cursor-pointer hover:border-blue-300 hover:shadow-md transition-all duration-200 group"
                      onClick={() => startGuide(guide)}
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          guide.difficulty_level === 'easy' ? 'bg-green-100' :
                          guide.difficulty_level === 'medium' ? 'bg-yellow-100' : 'bg-red-100'
                        }`}>
                          <Wrench className={`w-5 h-5 ${
                            guide.difficulty_level === 'easy' ? 'text-green-600' :
                            guide.difficulty_level === 'medium' ? 'text-yellow-600' : 'text-red-600'
                          }`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {guide.title}
                          </h3>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">{guide.service_type}</Badge>
                          <Badge variant="outline" className="text-xs">{guide.difficulty_level}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {guide.estimated_time_minutes} minutes
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
