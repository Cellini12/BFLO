import React, { useState, useEffect, useMemo } from "react";
import { useUser } from "@/components/hooks/useUser";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  History,
  Calendar,
  DollarSign,
  FileText,
  Wrench,
  Download,
  Filter,
  TrendingUp,
  CheckCircle,
  Clock,
  AlertCircle,
  Building,
  Search
} from "lucide-react";
import { format, startOfMonth, endOfMonth, startOfYear, subMonths, subYears } from "date-fns";

export default function ServiceHistory() {
  const { user, isLoading: isUserLoading } = useUser();
  const [jobs, setJobs] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [maintenanceReminders, setMaintenanceReminders] = useState([]);
  const [properties, setProperties] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [dateRange, setDateRange] = useState('all');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [selectedProperty, setSelectedProperty] = useState('all');
  const [serviceTypeFilter, setServiceTypeFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const [userJobs, userInvoices, userMaintenance, userProperties] = await Promise.all([
        base44.entities.Job.filter({ customer_id: user.id }, "-created_date", 500),
        base44.entities.Invoice.filter({ customer_id: user.id }, "-issue_date", 500),
        base44.entities.MaintenanceReminder.filter({ customer_id: user.id }, "-created_date", 500),
        base44.entities.Property.filter({ owner_id: user.id }, "-created_date", 50)
      ]);

      setJobs(userJobs);
      setInvoices(userInvoices);
      setMaintenanceReminders(userMaintenance);
      setProperties(userProperties);
    } catch (error) {
      console.error("Error loading service history:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getDateRangeFilter = () => {
    const now = new Date();
    switch (dateRange) {
      case 'this_month':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case 'last_month':
        return { start: startOfMonth(subMonths(now, 1)), end: endOfMonth(subMonths(now, 1)) };
      case 'last_3_months':
        return { start: subMonths(now, 3), end: now };
      case 'last_6_months':
        return { start: subMonths(now, 6), end: now };
      case 'this_year':
        return { start: startOfYear(now), end: now };
      case 'last_year':
        return { start: startOfYear(subYears(now, 1)), end: endOfMonth(subYears(now, 1)) };
      case 'custom':
        return {
          start: customStartDate ? new Date(customStartDate) : null,
          end: customEndDate ? new Date(customEndDate) : null
        };
      default:
        return { start: null, end: null };
    }
  };

  const filteredJobs = useMemo(() => {
    let filtered = [...jobs];
    const { start, end } = getDateRangeFilter();

    if (start) {
      filtered = filtered.filter(job => new Date(job.created_date) >= start);
    }
    if (end) {
      filtered = filtered.filter(job => new Date(job.created_date) <= end);
    }
    if (selectedProperty !== 'all') {
      filtered = filtered.filter(job => job.property_address === selectedProperty);
    }
    if (serviceTypeFilter !== 'all') {
      filtered = filtered.filter(job => job.service_type === serviceTypeFilter);
    }
    if (searchTerm) {
      filtered = filtered.filter(job => 
        job.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.property_address?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  }, [jobs, dateRange, customStartDate, customEndDate, selectedProperty, serviceTypeFilter, searchTerm]);

  const filteredInvoices = useMemo(() => {
    let filtered = [...invoices];
    const { start, end } = getDateRangeFilter();

    if (start) {
      filtered = filtered.filter(inv => new Date(inv.issue_date) >= start);
    }
    if (end) {
      filtered = filtered.filter(inv => new Date(inv.issue_date) <= end);
    }
    if (searchTerm) {
      filtered = filtered.filter(inv => 
        inv.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  }, [invoices, dateRange, customStartDate, customEndDate, searchTerm]);

  const completedJobs = filteredJobs.filter(j => j.status === 'completed');
  const totalSpent = filteredInvoices.filter(i => i.status === 'paid').reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
  const averageJobCost = completedJobs.length > 0 ? totalSpent / completedJobs.length : 0;

  const serviceTypeBreakdown = filteredJobs.reduce((acc, job) => {
    acc[job.service_type] = (acc[job.service_type] || 0) + 1;
    return acc;
  }, {});

  const allRecords = useMemo(() => {
    const records = [];
    
    filteredJobs.forEach(job => {
      records.push({
        id: job.id,
        type: 'job',
        date: new Date(job.created_date),
        title: job.title,
        description: job.description,
        property: job.property_address,
        status: job.status,
        serviceType: job.service_type,
        amount: null,
        data: job
      });
    });

    filteredInvoices.forEach(inv => {
      records.push({
        id: inv.id,
        type: 'invoice',
        date: new Date(inv.issue_date),
        title: inv.invoice_number,
        description: `Invoice for ${inv.invoice_number}`,
        property: null,
        status: inv.status,
        amount: inv.total_amount,
        data: inv
      });
    });

    maintenanceReminders.forEach(reminder => {
      if (reminder.last_service_date) {
        records.push({
          id: reminder.id,
          type: 'maintenance',
          date: new Date(reminder.last_service_date),
          title: reminder.title,
          description: reminder.description,
          property: null,
          status: 'completed',
          serviceType: reminder.service_type,
          amount: null,
          data: reminder
        });
      }
    });

    return records.sort((a, b) => b.date - a.date);
  }, [filteredJobs, filteredInvoices, maintenanceReminders]);

  const exportToCSV = () => {
    const headers = ['Date', 'Type', 'Title', 'Description', 'Property', 'Status', 'Service Type', 'Amount'];
    const rows = allRecords.map(record => [
      format(record.date, 'yyyy-MM-dd'),
      record.type,
      record.title,
      record.description,
      record.property || 'N/A',
      record.status,
      record.serviceType || 'N/A',
      record.amount ? `$${record.amount}` : 'N/A'
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `service-history-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  if (isLoading || isUserLoading) {
    return (
      <div className="p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
        <div className="animate-pulse space-y-4 max-w-7xl mx-auto">
          <div className="h-10 w-1/3 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <History className="w-8 h-8 text-blue-600" />
              Service History
            </h1>
            <p className="text-gray-600 mt-1">Complete record of all your services, invoices, and maintenance</p>
          </div>
          <Button onClick={exportToCSV} variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Export to CSV
          </Button>
        </div>

        {/* Summary Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Jobs</p>
                  <p className="text-3xl font-bold text-gray-900">{filteredJobs.length}</p>
                </div>
                <Wrench className="w-10 h-10 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Completed</p>
                  <p className="text-3xl font-bold text-green-600">{completedJobs.length}</p>
                </div>
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Spent</p>
                  <p className="text-3xl font-bold text-gray-900">${totalSpent.toLocaleString()}</p>
                </div>
                <DollarSign className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Job Cost</p>
                  <p className="text-3xl font-bold text-gray-900">${averageJobCost.toFixed(0)}</p>
                </div>
                <TrendingUp className="w-10 h-10 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div>
                <Label>Date Range</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="this_month">This Month</SelectItem>
                    <SelectItem value="last_month">Last Month</SelectItem>
                    <SelectItem value="last_3_months">Last 3 Months</SelectItem>
                    <SelectItem value="last_6_months">Last 6 Months</SelectItem>
                    <SelectItem value="this_year">This Year</SelectItem>
                    <SelectItem value="last_year">Last Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {dateRange === 'custom' && (
                <>
                  <div>
                    <Label>Start Date</Label>
                    <Input type="date" value={customStartDate} onChange={(e) => setCustomStartDate(e.target.value)} />
                  </div>
                  <div>
                    <Label>End Date</Label>
                    <Input type="date" value={customEndDate} onChange={(e) => setCustomEndDate(e.target.value)} />
                  </div>
                </>
              )}

              {properties.length > 0 && (
                <div>
                  <Label>Property</Label>
                  <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Properties</SelectItem>
                      {properties.map(prop => (
                        <SelectItem key={prop.id} value={prop.property_address}>
                          {prop.property_address}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <Label>Service Type</Label>
                <Select value={serviceTypeFilter} onValueChange={setServiceTypeFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="plumbing">Plumbing</SelectItem>
                    <SelectItem value="electrical">Electrical</SelectItem>
                    <SelectItem value="hvac">HVAC</SelectItem>
                    <SelectItem value="general_maintenance">General Maintenance</SelectItem>
                    <SelectItem value="landscaping">Landscaping</SelectItem>
                    <SelectItem value="painting">Painting</SelectItem>
                    <SelectItem value="roofing">Roofing</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Search</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Service Type Breakdown */}
        {Object.keys(serviceTypeBreakdown).length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Service Type Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                {Object.entries(serviceTypeBreakdown).map(([type, count]) => (
                  <div key={type} className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600 capitalize">{type.replace('_', ' ')}</p>
                    <p className="text-2xl font-bold text-gray-900">{count}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* History Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">All Records ({allRecords.length})</TabsTrigger>
            <TabsTrigger value="jobs">Jobs ({filteredJobs.length})</TabsTrigger>
            <TabsTrigger value="invoices">Invoices ({filteredInvoices.length})</TabsTrigger>
            <TabsTrigger value="maintenance">Maintenance ({maintenanceReminders.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4 mt-6">
            {allRecords.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No records found for the selected filters</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {allRecords.map((record) => (
                  <Card key={`${record.type}-${record.id}`} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <Badge variant={record.type === 'job' ? 'default' : record.type === 'invoice' ? 'secondary' : 'outline'}>
                              {record.type}
                            </Badge>
                            <h3 className="font-semibold text-gray-900">{record.title}</h3>
                            {record.status && (
                              <Badge variant="outline" className={
                                record.status === 'completed' || record.status === 'paid' ? 'bg-green-100 text-green-800' :
                                record.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                record.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-gray-100 text-gray-800'
                              }>
                                {record.status.replace('_', ' ')}
                              </Badge>
                            )}
                          </div>
                          <p className="text-gray-600 text-sm mb-2">{record.description}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {format(record.date, 'MMM d, yyyy')}
                            </span>
                            {record.property && (
                              <span className="flex items-center gap-1">
                                <Building className="w-4 h-4" />
                                {record.property}
                              </span>
                            )}
                            {record.serviceType && (
                              <span className="capitalize">{record.serviceType.replace('_', ' ')}</span>
                            )}
                          </div>
                        </div>
                        {record.amount && (
                          <div className="text-right">
                            <p className="text-2xl font-bold text-green-600">${record.amount.toLocaleString()}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="jobs" className="space-y-4 mt-6">
            {filteredJobs.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Wrench className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No jobs found for the selected filters</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {filteredJobs.map((job) => (
                  <Card key={job.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-gray-900">{job.title}</h3>
                            <Badge variant="outline" className={
                              job.status === 'completed' ? 'bg-green-100 text-green-800' :
                              job.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                              job.status === 'scheduled' ? 'bg-purple-100 text-purple-800' :
                              'bg-yellow-100 text-yellow-800'
                            }>
                              {job.status.replace('_', ' ')}
                            </Badge>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">{job.description}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {format(new Date(job.created_date), 'MMM d, yyyy')}
                            </span>
                            <span className="flex items-center gap-1">
                              <Building className="w-4 h-4" />
                              {job.property_address}
                            </span>
                            <span className="capitalize">{job.service_type.replace('_', ' ')}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="invoices" className="space-y-4 mt-6">
            {filteredInvoices.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No invoices found for the selected filters</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {filteredInvoices.map((invoice) => (
                  <Card key={invoice.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-gray-900">{invoice.invoice_number}</h3>
                            <Badge variant="outline" className={
                              invoice.status === 'paid' ? 'bg-green-100 text-green-800' :
                              invoice.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                              invoice.status === 'overdue' ? 'bg-red-100 text-red-800' :
                              'bg-gray-100 text-gray-800'
                            }>
                              {invoice.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              Issued: {format(new Date(invoice.issue_date), 'MMM d, yyyy')}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              Due: {format(new Date(invoice.due_date), 'MMM d, yyyy')}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-gray-900">${invoice.total_amount.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="maintenance" className="space-y-4 mt-6">
            {maintenanceReminders.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No maintenance records found</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {maintenanceReminders.map((reminder) => (
                  <Card key={reminder.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 mb-2">{reminder.title}</h3>
                          <p className="text-gray-600 text-sm mb-2">{reminder.description}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            {reminder.last_service_date && (
                              <span className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                Last: {format(new Date(reminder.last_service_date), 'MMM d, yyyy')}
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              Next: {format(new Date(reminder.next_due_date), 'MMM d, yyyy')}
                            </span>
                            <span className="capitalize">{reminder.service_type.replace('_', ' ')}</span>
                          </div>
                        </div>
                        <Badge variant={reminder.is_active ? 'default' : 'secondary'}>
                          {reminder.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}