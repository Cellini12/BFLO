import React, { useState, useEffect } from "react";
import { Job } from "@/api/entities";
import { Technician } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  MapPin, 
  Phone, 
  MessageCircle, 
  Clock, 
  Navigation,
  Star,
  User as UserIcon
} from "lucide-react";

export default function TechnicianTracking() {
  const [job, setJob] = useState(null);
  const [technician, setTechnician] = useState(null);
  const [estimatedArrival, setEstimatedArrival] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkUrlParams();
  }, []);

  const checkUrlParams = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const jobId = urlParams.get('job_id');
    if (jobId) {
      loadTrackingData(jobId);
    }
  };

  const loadTrackingData = async (jobId) => {
    try {
      const jobData = await Job.get(jobId);
      setJob(jobData);

      if (jobData.technician_id) {
        const technicianData = await Technician.get(jobData.technician_id);
        setTechnician(technicianData);
        
        // Calculate estimated arrival (mock calculation)
        const now = new Date();
        const arrival = new Date(now.getTime() + 25 * 60000); // 25 minutes from now
        setEstimatedArrival(arrival);
      }
    } catch (error) {
      console.error("Error loading tracking data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-16 bg-gray-200 rounded-xl"></div>
          <div className="h-64 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  if (!job || !technician) {
    return (
      <div className="p-6 lg:p-8 text-center">
        <h2 className="text-xl font-bold text-gray-900 mb-2">Tracking Not Available</h2>
        <p className="text-gray-600">No active tracking found for this job.</p>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Technician is On The Way</h1>
          <p className="text-gray-600">Track your service professional in real-time</p>
        </div>

        {/* Arrival Time */}
        <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 shadow-xl">
          <CardContent className="p-8 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Clock className="w-8 h-8" />
              <h2 className="text-2xl font-bold">Estimated Arrival</h2>
            </div>
            <p className="text-4xl font-extrabold mb-2">
              {estimatedArrival?.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </p>
            <p className="text-green-100">
              Approximately {Math.ceil((estimatedArrival - new Date()) / (1000 * 60))} minutes away
            </p>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6">
          
          {/* Technician Info */}
          <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="w-5 h-5" />
                Your Technician
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  {technician.photo_url ? (
                    <img src={technician.photo_url} alt={technician.name} className="w-16 h-16 rounded-full object-cover" />
                  ) : (
                    <UserIcon className="w-8 h-8 text-blue-600" />
                  )}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{technician.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm text-gray-600">{technician.rating?.toFixed(1)} ({technician.completed_jobs} jobs)</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Skills:</h4>
                  <div className="flex flex-wrap gap-2">
                    {technician.skills?.map((skill, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 pt-4">
                  <Button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
                    <Phone className="w-4 h-4" />
                    Call
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <MessageCircle className="w-4 h-4" />
                    Message
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Job Details */}
          <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
            <CardHeader>
              <CardTitle>Service Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">{job.title}</h3>
                <p className="text-gray-600 text-sm">{job.description}</p>
              </div>
              
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{job.property_address}</span>
              </div>
              
              <div className="space-y-2">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  {job.status.replace('_', ' ')}
                </Badge>
                <p className="text-xs text-gray-500 capitalize">
                  {job.service_type.replace('_', ' ')} • {job.priority} priority
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Live Map Placeholder */}
        <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Navigation className="w-5 h-5" />
              Live Location
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Navigation className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
                <p className="text-blue-800 font-semibold">Live Map Integration</p>
                <p className="text-sm text-blue-600 mt-1">Real-time technician location tracking</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Status Updates */}
        <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
          <CardHeader>
            <CardTitle>Recent Updates</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-gray-900">Technician dispatched</p>
                  <p className="text-sm text-gray-500">2:15 PM - {technician.name} is on the way</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium text-gray-900">Job confirmed</p>
                  <p className="text-sm text-gray-500">1:45 PM - Service request approved and scheduled</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}