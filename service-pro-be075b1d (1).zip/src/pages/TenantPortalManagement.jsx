import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useUser } from "@/components/hooks/useUser";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Users,
  Plus,
  Send,
  Eye,
  EyeOff,
  Copy,
  CheckCircle,
  Loader2,
  MessageSquare,
  Link as LinkIcon
} from "lucide-react";
import { format } from "date-fns";

export default function TenantPortalManagement() {
  const { user, isLoading: isUserLoading } = useUser();
  const [portals, setPortals] = useState([]);
  const [tenantApplications, setTenantApplications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedPortal, setSelectedPortal] = useState(null);
  const [copiedCode, setCopiedCode] = useState(null);

  useEffect(() => {
    if (user && user.customer_type === 'landlord') {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const [portalAccesses, applications] = await Promise.all([
        base44.entities.TenantPortalAccess.filter({ landlord_id: user.id }, "-created_date", 100),
        base44.entities.TenantApplication.filter({ landlord_id: user.id, status: "approved" }, "-created_date", 100)
      ]);
      
      setPortals(portalAccesses);
      setTenantApplications(applications);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateAccessCode = () => {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  };

  const handleCreatePortal = async (application) => {
    try {
      const accessCode = generateAccessCode();
      const portalData = {
        landlord_id: user.id,
        tenant_email: application.tenant_email,
        tenant_name: application.tenant_full_name,
        property_address: application.property_address,
        access_code: accessCode,
        lease_start_date: application.lease_start_date,
        lease_end_date: application.lease_start_date ? 
          new Date(new Date(application.lease_start_date).setMonth(new Date(application.lease_start_date).getMonth() + application.lease_term_months)).toISOString().split('T')[0] : 
          null,
        monthly_rent: application.monthly_rent,
        rent_due_day: 1,
        is_active: true
      };

      // If there's an associated lease document, link it
      const leases = await base44.entities.LeaseDocument.filter({
        landlord_id: user.id,
        tenant_email: application.tenant_email,
        property_address: application.property_address
      }, "-created_date", 1);

      if (leases.length > 0) {
        portalData.lease_document_id = leases[0].id;
      }

      const newPortal = await base44.entities.TenantPortalAccess.create(portalData);

      // Send invitation email
      const portalUrl = `${window.location.origin}/TenantPortal`;
      await base44.integrations.Core.SendEmail({
        to: application.tenant_email,
        subject: "Welcome to Your Tenant Portal - BFLO Contracting",
        body: `Dear ${application.tenant_full_name},\n\nWelcome to your tenant portal! You can now access your lease details, submit maintenance requests, and communicate with your landlord.\n\nTo get started, visit: ${portalUrl}\n\nSign in with your email: ${application.tenant_email}\n\nYour portal access code: ${accessCode}\n\nBest regards,\n${user.full_name}\nBFLO Contracting`
      });

      await loadData();
      alert("Tenant portal created and invitation sent!");
    } catch (error) {
      console.error("Error creating portal:", error);
      alert("Failed to create tenant portal. Please try again.");
    }
  };

  const handleCopyAccessCode = (code) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleToggleActive = async (portal) => {
    try {
      await base44.entities.TenantPortalAccess.update(portal.id, {
        is_active: !portal.is_active
      });
      await loadData();
    } catch (error) {
      console.error("Error toggling portal status:", error);
    }
  };

  if (isUserLoading || isLoading) {
    return (
      <div className="p-8 bg-gray-100 min-h-screen">
        <div className="animate-pulse space-y-4 max-w-7xl mx-auto">
          <div className="h-10 w-1/3 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  if (!user || user.customer_type !== 'landlord') {
    return (
      <div className="p-8 bg-gray-100 min-h-screen">
        <Alert variant="destructive">
          <AlertDescription>
            This page is only accessible to landlords.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Find applications that don't have portals yet
  const applicationsWithoutPortals = tenantApplications.filter(app => 
    !portals.some(portal => 
      portal.tenant_email === app.tenant_email && 
      portal.property_address === app.property_address
    )
  );

  return (
    <div className="p-4 lg:p-8 bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Tenant Portal Management</h1>
            <p className="text-gray-600">Manage tenant portal access and invitations</p>
          </div>
        </div>

        {/* Approved Applications Without Portals */}
        {applicationsWithoutPortals.length > 0 && (
          <Card className="bg-blue-50 border-blue-200 shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-900 flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Ready to Create Portals ({applicationsWithoutPortals.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {applicationsWithoutPortals.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-4 bg-white rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-900">{app.tenant_full_name}</p>
                      <p className="text-sm text-gray-600">{app.property_address}</p>
                      <p className="text-xs text-gray-500">{app.tenant_email}</p>
                    </div>
                    <Button onClick={() => handleCreatePortal(app)} className="bg-blue-600 hover:bg-blue-700">
                      <Send className="w-4 h-4 mr-2" />
                      Create Portal & Send Invite
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Active Portals */}
        <Card className="bg-white border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Active Tenant Portals ({portals.filter(p => p.is_active).length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {portals.map((portal) => (
                <div key={portal.id} className="p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold text-gray-900">{portal.tenant_name}</h4>
                        <Badge className={portal.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                          {portal.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{portal.property_address}</p>
                      <p className="text-xs text-gray-500 mt-1">{portal.tenant_email}</p>
                      
                      <div className="flex items-center gap-4 mt-3">
                        <div className="text-xs text-gray-600">
                          <span className="font-medium">Rent:</span> ${portal.monthly_rent}/month
                        </div>
                        {portal.last_login && (
                          <div className="text-xs text-gray-600">
                            <span className="font-medium">Last Login:</span> {format(new Date(portal.last_login), 'MMM d, yyyy')}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-3 p-2 bg-gray-100 rounded">
                        <LinkIcon className="w-4 h-4 text-gray-600" />
                        <code className="text-xs text-gray-700">{window.location.origin}/TenantPortal</code>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyAccessCode(portal.access_code)}
                          className="ml-auto"
                        >
                          {copiedCode === portal.access_code ? (
                            <>
                              <CheckCircle className="w-4 h-4 mr-1 text-green-600" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4 mr-1" />
                              Copy Code
                            </>
                          )}
                        </Button>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleActive(portal)}
                      >
                        {portal.is_active ? (
                          <>
                            <EyeOff className="w-4 h-4 mr-2" />
                            Deactivate
                          </>
                        ) : (
                          <>
                            <Eye className="w-4 h-4 mr-2" />
                            Activate
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              {portals.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No Tenant Portals Yet</h3>
                  <p className="text-gray-600 mb-6">
                    Create portals for your approved tenants to give them access to lease details, maintenance requests, and more.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}