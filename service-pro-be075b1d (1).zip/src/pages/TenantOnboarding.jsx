
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useUser } from "@/components/hooks/useUser";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import {
  CheckCircle,
  Home,
  User,
  Briefcase,
  FileText,
  CreditCard,
  ArrowRight,
  ArrowLeft,
  Check,
  Loader2
} from "lucide-react";

const STEPS = [
  { id: 1, title: "Personal Info", icon: User },
  { id: 2, title: "Employment", icon: Briefcase },
  { id: 3, title: "References", icon: FileText },
  { id: 4, title: "Payment Setup", icon: CreditCard },
  { id: 5, title: "Review & Submit", icon: CheckCircle }
];

export default function TenantOnboarding() {
  const { user, isLoading: isUserLoading } = useUser();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [applicationId, setApplicationId] = useState(null);
  const [formData, setFormData] = useState({
    tenant_full_name: "",
    tenant_email: "",
    tenant_phone: "",
    date_of_birth: "",
    current_address: "",
    employment_status: "employed",
    employer_name: "",
    monthly_income: "",
    lease_start_date: "",
    lease_term_months: 12,
    property_address: "",
    monthly_rent: "",
    references: [
      { name: "", relationship: "", phone: "", email: "" },
      { name: "", relationship: "", phone: "", email: "" }
    ],
    emergency_contact: { name: "", relationship: "", phone: "" },
    pets: false,
    pet_details: "",
    payment_method: "bank_transfer",
    bank_account_last4: "",
    documents_signed: false
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const landlordId = urlParams.get('landlord_id');
    const propertyAddress = urlParams.get('property');
    const monthlyRent = urlParams.get('rent');
    const appId = urlParams.get('app_id');
    
    if (appId) {
      loadExistingApplication(appId);
    } else {
      if (propertyAddress) {
        setFormData(prev => ({ ...prev, property_address: propertyAddress }));
      }
      if (monthlyRent) {
        setFormData(prev => ({ ...prev, monthly_rent: parseFloat(monthlyRent) }));
      }
    }
  }, []);

  const loadExistingApplication = async (appId) => {
    try {
      const app = await base44.entities.TenantApplication.get(appId);
      setFormData(app);
      setApplicationId(appId);
      if (app.status === 'draft') {
        setCurrentStep(1);
      }
    } catch (error) {
      console.error("Error loading application:", error);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleReferenceChange = (index, field, value) => {
    const updatedRefs = [...formData.references];
    updatedRefs[index][field] = value;
    setFormData(prev => ({ ...prev, references: updatedRefs }));
  };

  const handleEmergencyContactChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      emergency_contact: { ...prev.emergency_contact, [field]: value }
    }));
  };

  const saveDraft = async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const landlordId = urlParams.get('landlord_id');
      
      const dataToSave = {
        ...formData,
        landlord_id: landlordId,
        status: 'draft'
      };

      if (applicationId) {
        await base44.entities.TenantApplication.update(applicationId, dataToSave);
      } else {
        const newApp = await base44.entities.TenantApplication.create(dataToSave);
        setApplicationId(newApp.id);
      }
    } catch (error) {
      console.error("Error saving draft:", error);
    }
  };

  const nextStep = async () => {
    await saveDraft();
    setCurrentStep(prev => Math.min(prev + 1, STEPS.length));
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const runAIScreening = async (applicationData) => {
    try {
      // Calculate income-to-rent ratio
      const incomeToRentRatio = applicationData.monthly_rent && applicationData.monthly_income ?
        applicationData.monthly_income / applicationData.monthly_rent : 0;
      
      // Prepare screening prompt
      const prompt = `You are an expert tenant screening AI. Analyze this rental application and provide a comprehensive risk assessment.

APPLICATION DATA:
- Applicant: ${applicationData.tenant_full_name}
- Age: ${applicationData.date_of_birth ? new Date().getFullYear() - new Date(applicationData.date_of_birth).getFullYear() : 'N/A'} years old
- Employment Status: ${applicationData.employment_status}
- Employer: ${applicationData.employer_name || 'N/A'}
- Monthly Income: $${applicationData.monthly_income || 0}
- Monthly Rent: $${applicationData.monthly_rent || 0}
- Income-to-Rent Ratio: ${incomeToRentRatio.toFixed(2)}x
- Lease Term: ${applicationData.lease_term_months} months
- Has Pets: ${applicationData.pets ? 'Yes - ' + applicationData.pet_details : 'No'}
- References Provided: ${applicationData.references.filter(r => r.name).length}
- Payment Method: ${applicationData.payment_method}

SCREENING CRITERIA:
1. Income should be at least 3x monthly rent (ideal: 3.5x+)
2. Stable employment is preferred
3. Having 2+ valid references is positive
4. Age considerations (very young applicants may need co-signers)
5. Pet policies (large/aggressive breeds may be concerns)
6. Payment method reliability

Provide a thorough risk assessment with actionable insights for the landlord.`;

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            risk_score: {
              type: "number",
              description: "Risk score from 0-100, where 0 is no risk and 100 is highest risk"
            },
            risk_level: {
              type: "string",
              enum: ["low", "medium", "high", "critical"],
              description: "Overall risk level classification"
            },
            screening_summary: {
              type: "string",
              description: "Concise 2-3 sentence summary of the screening findings"
            },
            red_flags: {
              type: "array",
              items: { type: "string" },
              description: "List of concerning factors identified"
            },
            positive_factors: {
              type: "array",
              items: { type: "string" },
              description: "List of favorable factors identified"
            },
            requires_manual_review: {
              type: "boolean",
              description: "Whether this application should be manually reviewed"
            },
            manual_review_reasons: {
              type: "array",
              items: { type: "string" },
              description: "Specific reasons why manual review is needed"
            },
            recommendations: {
              type: "array",
              items: { type: "string" },
              description: "Specific recommendations for the landlord"
            }
          },
          required: ["risk_score", "risk_level", "screening_summary"]
        }
      });

      return {
        ai_risk_score: aiResponse.risk_score,
        ai_risk_level: aiResponse.risk_level,
        ai_screening_summary: aiResponse.screening_summary,
        ai_red_flags: aiResponse.red_flags || [],
        ai_positive_factors: aiResponse.positive_factors || [],
        requires_manual_review: aiResponse.requires_manual_review,
        manual_review_reasons: aiResponse.manual_review_reasons || [],
        ai_screening_completed: true,
        ai_screening_date: new Date().toISOString()
      };
    } catch (error) {
      console.error("AI Screening error:", error);
      return {
        ai_screening_completed: false,
        requires_manual_review: true,
        manual_review_reasons: ["AI screening failed - manual review required"]
      };
    }
  };

  const submitApplication = async () => {
    setIsSubmitting(true);
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const landlordId = urlParams.get('landlord_id');
      
      // Run AI screening
      const aiScreeningResults = await runAIScreening(formData);
      
      const finalData = {
        ...formData,
        ...aiScreeningResults,
        landlord_id: landlordId,
        status: 'submitted',
        documents_signed: true,
        signature_date: new Date().toISOString()
      };

      if (applicationId) {
        await base44.entities.TenantApplication.update(applicationId, finalData);
      } else {
        await base44.entities.TenantApplication.create(finalData);
      }

      alert("Application submitted successfully! AI screening completed. The landlord will review your application.");
      window.location.href = "/";
    } catch (error) {
      console.error("Error submitting application:", error);
      alert("Error submitting application. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Personal Information</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="tenant_full_name">Full Name *</Label>
                <Input
                  id="tenant_full_name"
                  value={formData.tenant_full_name}
                  onChange={(e) => handleInputChange('tenant_full_name', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="tenant_email">Email Address *</Label>
                <Input
                  id="tenant_email"
                  type="email"
                  value={formData.tenant_email}
                  onChange={(e) => handleInputChange('tenant_email', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="tenant_phone">Phone Number *</Label>
                <Input
                  id="tenant_phone"
                  value={formData.tenant_phone}
                  onChange={(e) => handleInputChange('tenant_phone', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="date_of_birth">Date of Birth *</Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  value={formData.date_of_birth}
                  onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="current_address">Current Address *</Label>
              <Input
                id="current_address"
                value={formData.current_address}
                onChange={(e) => handleInputChange('current_address', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="property_address">Applying For Property *</Label>
              <Input
                id="property_address"
                value={formData.property_address}
                onChange={(e) => handleInputChange('property_address', e.target.value)}
                required
              />
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="lease_start_date">Desired Move-In Date *</Label>
                <Input
                  id="lease_start_date"
                  type="date"
                  value={formData.lease_start_date}
                  onChange={(e) => handleInputChange('lease_start_date', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="lease_term_months">Lease Term (months) *</Label>
                <Input
                  id="lease_term_months"
                  type="number"
                  value={formData.lease_term_months}
                  onChange={(e) => handleInputChange('lease_term_months', parseInt(e.target.value))}
                  required
                />
              </div>
              <div>
                <Label htmlFor="monthly_rent">Monthly Rent *</Label>
                <Input
                  id="monthly_rent"
                  type="number"
                  value={formData.monthly_rent}
                  onChange={(e) => handleInputChange('monthly_rent', parseFloat(e.target.value))}
                  placeholder="$0.00"
                  required
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Employment Information</h3>
            <div>
              <Label htmlFor="employment_status">Employment Status *</Label>
              <select
                id="employment_status"
                value={formData.employment_status}
                onChange={(e) => handleInputChange('employment_status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="employed">Employed</option>
                <option value="self_employed">Self-Employed</option>
                <option value="unemployed">Unemployed</option>
                <option value="student">Student</option>
                <option value="retired">Retired</option>
              </select>
            </div>
            {(formData.employment_status === 'employed' || formData.employment_status === 'self_employed') && (
              <>
                <div>
                  <Label htmlFor="employer_name">Employer/Company Name *</Label>
                  <Input
                    id="employer_name"
                    value={formData.employer_name}
                    onChange={(e) => handleInputChange('employer_name', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="monthly_income">Monthly Income *</Label>
                  <Input
                    id="monthly_income"
                    type="number"
                    value={formData.monthly_income}
                    onChange={(e) => handleInputChange('monthly_income', parseFloat(e.target.value))}
                    placeholder="$0.00"
                    required
                  />
                </div>
              </>
            )}
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">References & Emergency Contact</h3>
            
            <div className="space-y-4">
              <h4 className="font-medium text-gray-900">References (at least 2)</h4>
              {formData.references.map((ref, index) => (
                <div key={index} className="p-4 border border-gray-200 rounded-lg space-y-4">
                  <h5 className="font-medium text-sm text-gray-700">Reference #{index + 1}</h5>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Name</Label>
                      <Input
                        value={ref.name}
                        onChange={(e) => handleReferenceChange(index, 'name', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Relationship</Label>
                      <Input
                        value={ref.relationship}
                        onChange={(e) => handleReferenceChange(index, 'relationship', e.target.value)}
                        placeholder="e.g., Previous Landlord, Employer"
                      />
                    </div>
                    <div>
                      <Label>Phone</Label>
                      <Input
                        value={ref.phone}
                        onChange={(e) => handleReferenceChange(index, 'phone', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Email</Label>
                      <Input
                        type="email"
                        value={ref.email}
                        onChange={(e) => handleReferenceChange(index, 'email', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-gray-900">Emergency Contact</h4>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Name *</Label>
                  <Input
                    value={formData.emergency_contact.name}
                    onChange={(e) => handleEmergencyContactChange('name', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label>Relationship *</Label>
                  <Input
                    value={formData.emergency_contact.relationship}
                    onChange={(e) => handleEmergencyContactChange('relationship', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label>Phone *</Label>
                  <Input
                    value={formData.emergency_contact.phone}
                    onChange={(e) => handleEmergencyContactChange('phone', e.target.value)}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Do you have pets?</Label>
                <Switch
                  checked={formData.pets}
                  onCheckedChange={(checked) => handleInputChange('pets', checked)}
                />
              </div>
              {formData.pets && (
                <div>
                  <Label>Pet Details</Label>
                  <Textarea
                    value={formData.pet_details}
                    onChange={(e) => handleInputChange('pet_details', e.target.value)}
                    placeholder="Type, breed, weight, etc."
                    rows={3}
                  />
                </div>
              )}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Payment Information</h3>
            <Alert>
              <AlertDescription>
                Set up your preferred payment method for rent payments.
              </AlertDescription>
            </Alert>
            <div>
              <Label htmlFor="payment_method">Payment Method *</Label>
              <select
                id="payment_method"
                value={formData.payment_method}
                onChange={(e) => handleInputChange('payment_method', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="bank_transfer">Bank Transfer (ACH)</option>
                <option value="credit_card">Credit Card</option>
                <option value="check">Check</option>
                <option value="cash">Cash</option>
              </select>
            </div>
            {formData.payment_method === 'bank_transfer' && (
              <div>
                <Label htmlFor="bank_account_last4">Bank Account Last 4 Digits *</Label>
                <Input
                  id="bank_account_last4"
                  value={formData.bank_account_last4}
                  onChange={(e) => handleInputChange('bank_account_last4', e.target.value)}
                  maxLength={4}
                  placeholder="1234"
                />
                <p className="text-xs text-gray-500 mt-1">
                  For verification purposes only. Full account details will be collected securely after approval.
                </p>
              </div>
            )}
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Review & Submit</h3>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Application Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-700 mb-2">Personal Information</h4>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p><strong>Name:</strong> {formData.tenant_full_name}</p>
                    <p><strong>Email:</strong> {formData.tenant_email}</p>
                    <p><strong>Phone:</strong> {formData.tenant_phone}</p>
                    <p><strong>Property:</strong> {formData.property_address}</p>
                    <p><strong>Move-In Date:</strong> {formData.lease_start_date}</p>
                    <p><strong>Monthly Rent:</strong> ${formData.monthly_rent}</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-gray-700 mb-2">Employment</h4>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p><strong>Status:</strong> {formData.employment_status}</p>
                    {formData.employer_name && <p><strong>Employer:</strong> {formData.employer_name}</p>}
                    {formData.monthly_income && <p><strong>Monthly Income:</strong> ${formData.monthly_income}</p>}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-gray-700 mb-2">Payment Method</h4>
                  <div className="text-sm text-gray-600">
                    <p>{formData.payment_method.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium mb-1">Lease Agreement & AI Screening</p>
                  <p className="text-blue-700 mb-3">
                    By submitting this application, you agree to the terms and conditions of the lease agreement. 
                    Your application will be automatically screened using AI to assess eligibility. 
                    You will receive the full lease documents for review after your application is approved.
                  </p>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.documents_signed}
                      onCheckedChange={(checked) => handleInputChange('documents_signed', checked)}
                    />
                    <Label className="cursor-pointer">
                      I agree to the terms and conditions
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const progress = (currentStep / STEPS.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4 lg:p-8">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Home className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Tenant Application</h1>
          </div>
          <p className="text-gray-600">Complete your application to secure your new home</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <Progress value={progress} className="h-3 mb-4" />
          <div className="flex justify-between">
            {STEPS.map((step) => (
              <div
                key={step.id}
                className={`flex flex-col items-center ${
                  step.id <= currentStep ? 'text-blue-600' : 'text-gray-400'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                    step.id < currentStep
                      ? 'bg-green-500 text-white'
                      : step.id === currentStep
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200'
                  }`}
                >
                  {step.id < currentStep ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <step.icon className="w-5 h-5" />
                  )}
                </div>
                <span className="text-xs font-medium text-center hidden md:block">{step.title}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <Card className="bg-white/80 backdrop-blur border-0 shadow-xl mb-6">
          <CardContent className="p-6 lg:p-8">
            {renderStepContent()}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          {currentStep < STEPS.length ? (
            <Button
              onClick={nextStep}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={submitApplication}
              disabled={!formData.documents_signed || isSubmitting}
              className="bg-green-600 hover:bg-green-700"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting & Screening...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Submit Application
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
