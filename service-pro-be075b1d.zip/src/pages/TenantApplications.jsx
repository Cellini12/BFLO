
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useUser } from "@/components/hooks/useUser";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  Clock,
  CheckCircle,
  XCircle,
  Mail,
  Phone,
  Briefcase,
  Home,
  DollarSign,
  Calendar,
  FileText,
  AlertTriangle,
  ThumbsUp,
  ThumbsDown,
  Eye,
  Link as LinkIcon,
  Bot,
  ShieldAlert,
  ShieldCheck,
  Flag,
  Sparkles
} from "lucide-react";
import { format } from "date-fns";
import { createPageUrl } from "@/utils";

const statusColors = {
  draft: "bg-gray-100 text-gray-800",
  submitted: "bg-blue-100 text-blue-800",
  under_review: "bg-yellow-100 text-yellow-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800"
};

const statusIcons = {
  draft: FileText,
  submitted: Clock,
  under_review: Eye,
  approved: CheckCircle,
  rejected: XCircle
};

const riskLevelColors = {
  low: "bg-green-100 text-green-800 border-green-300",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-300",
  high: "bg-orange-100 text-orange-800 border-orange-300",
  critical: "bg-red-100 text-red-800 border-red-300"
};

const riskLevelIcons = {
  low: ShieldCheck,
  medium: AlertTriangle,
  high: ShieldAlert,
  critical: XCircle
};

export default function TenantApplications() {
  const { user, isLoading: isUserLoading } = useUser();
  const [applications, setApplications] = useState([]);
  const [selectedApp, setSelectedApp] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [landlordNotes, setLandlordNotes] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");
  const [activeTab, setActiveTab] = useState("submitted");

  useEffect(() => {
    if (user && user.customer_type === 'landlord') {
      loadApplications();
    }
  }, [user]);

  const loadApplications = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      const apps = await base44.entities.TenantApplication.filter(
        { landlord_id: user.id },
        "-created_date",
        100
      );
      setApplications(apps);
      
      const urlParams = new URLSearchParams(window.location.search);
      const appId = urlParams.get('app_id');
      if (appId) {
        const app = apps.find(a => a.id === appId);
        if (app) setSelectedApp(app);
      } else if (apps.length > 0 && apps.some(a => a.status === 'submitted')) {
        setSelectedApp(apps.find(a => a.status === 'submitted'));
      }
    } catch (error) {
      console.error("Error loading applications:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateApplicationStatus = async (appId, status, additionalData = {}) => {
    try {
      await base44.entities.TenantApplication.update(appId, {
        status,
        ...additionalData
      });
      await loadApplications();
      setSelectedApp(null);
      setLandlordNotes("");
      setRejectionReason("");
    } catch (error) {
      console.error("Error updating application:", error);
    }
  };

  const handleReview = (appId) => {
    updateApplicationStatus(appId, "under_review", {
      landlord_notes: landlordNotes
    });
  };

  const handleApprove = (appId) => {
    updateApplicationStatus(appId, "approved", {
      approved_date: new Date().toISOString(),
      landlord_notes: landlordNotes
    });
  };

  const handleReject = (appId) => {
    if (!rejectionReason.trim()) {
      alert("Please provide a reason for rejection");
      return;
    }
    updateApplicationStatus(appId, "rejected", {
      rejection_reason: rejectionReason,
      landlord_notes: landlordNotes
    });
  };

  const generateOnboardingLink = (propertyAddress, monthlyRent) => {
    const baseUrl = window.location.origin;
    const params = new URLSearchParams({
      landlord_id: user.id,
      property: propertyAddress,
      rent: monthlyRent || ''
    });
    return `${baseUrl}${createPageUrl("TenantOnboarding")}?${params.toString()}`;
  };

  const copyOnboardingLink = (propertyAddress, monthlyRent) => {
    const link = generateOnboardingLink(propertyAddress, monthlyRent);
    navigator.clipboard.writeText(link);
    alert("Onboarding link copied to clipboard!");
  };

  const filteredApplications = applications.filter(app => {
    if (activeTab === "all") return true;
    if (activeTab === "flagged") return app.requires_manual_review;
    return app.status === activeTab;
  });

  if (isUserLoading || isLoading) {
    return (
      <div className="p-8 bg-gray-100 min-h-screen">
        <div className="animate-pulse space-y-4 max-w-7xl mx-auto">
          <div className="h-10 w-1/3 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  if (!user || user.customer_type !== 'landlord') {
    return (
      <div className="p-8 bg-gray-100 min-h-screen">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This page is only accessible to landlords. Please update your profile to landlord account type.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Tenant Applications</h1>
            <p className="text-gray-600">AI-powered screening & application management</p>
          </div>
          
          <div className="flex flex-wrap gap-3">
            {user.properties && user.properties.length > 0 && (
              <div className="relative group">
                <Button variant="outline" className="border-blue-300 text-blue-700">
                  <LinkIcon className="w-4 h-4 mr-2" />
                  Get Onboarding Links
                </Button>
                <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 p-4 hidden group-hover:block z-10">
                  <h3 className="font-semibold mb-3">Property Onboarding Links</h3>
                  <div className="space-y-2">
                    {user.properties.map((prop, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <span className="text-sm truncate flex-1">{prop.address}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyOnboardingLink(prop.address, prop.rent)}
                        >
                          Copy Link
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-5 gap-4">
          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total</p>
                  <p className="text-3xl font-bold text-gray-900">{applications.length}</p>
                </div>
                <Users className="w-10 h-10 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-3xl font-bold text-yellow-600">
                    {applications.filter(a => a.status === 'submitted').length}
                  </p>
                </div>
                <Clock className="w-10 h-10 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Flagged</p>
                  <p className="text-3xl font-bold text-orange-600">
                    {applications.filter(a => a.requires_manual_review).length}
                  </p>
                </div>
                <Flag className="w-10 h-10 text-orange-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Approved</p>
                  <p className="text-3xl font-bold text-green-600">
                    {applications.filter(a => a.status === 'approved').length}
                  </p>
                </div>
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Rejected</p>
                  <p className="text-3xl font-bold text-red-600">
                    {applications.filter(a => a.status === 'rejected').length}
                  </p>
                </div>
                <XCircle className="w-10 h-10 text-red-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-6">
          
          {/* Applications List */}
          <div className="lg:col-span-1">
            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Applications</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-4 mb-4">
                    <TabsTrigger value="submitted">New</TabsTrigger>
                    <TabsTrigger value="flagged">
                      <Flag className="w-3 h-3" />
                    </TabsTrigger>
                    <TabsTrigger value="under_review">Review</TabsTrigger>
                    <TabsTrigger value="all">All</TabsTrigger>
                  </TabsList>
                </Tabs>

                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {filteredApplications.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No applications found</p>
                  ) : (
                    filteredApplications.map((app) => {
                      const StatusIcon = statusIcons[app.status];
                      const RiskIcon = app.ai_risk_level ? riskLevelIcons[app.ai_risk_level] : null;
                      
                      return (
                        <div
                          key={app.id}
                          onClick={() => setSelectedApp(app)}
                          className={`p-4 border rounded-lg cursor-pointer transition-all ${
                            selectedApp?.id === app.id
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-semibold text-gray-900">{app.tenant_full_name}</h3>
                            <div className="flex gap-1">
                              <Badge className={statusColors[app.status]}>
                                <StatusIcon className="w-3 h-3 mr-1" />
                                {app.status.replace('_', ' ')}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{app.property_address}</p>
                          
                          {app.ai_screening_completed && app.ai_risk_level && (
                            <div className="flex items-center gap-2 mt-2">
                              <Badge className={`${riskLevelColors[app.ai_risk_level]} border text-xs`}>
                                {RiskIcon && <RiskIcon className="w-3 h-3 mr-1" />}
                                {app.ai_risk_level.toUpperCase()} RISK
                              </Badge>
                              {app.requires_manual_review && (
                                <Badge className="bg-orange-100 text-orange-800 text-xs">
                                  <Flag className="w-3 h-3 mr-1" />
                                  Flagged
                                </Badge>
                              )}
                            </div>
                          )}
                          
                          <p className="text-xs text-gray-500 mt-2">
                            Applied {format(new Date(app.created_date), 'MMM d, yyyy')}
                          </p>
                        </div>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Application Details */}
          <div className="lg:col-span-2">
            {selectedApp ? (
              <div className="space-y-6">
                
                {/* AI Screening Results */}
                {selectedApp.ai_screening_completed && (
                  <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-200 shadow-xl">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Bot className="w-6 h-6 text-purple-600" />
                        AI Screening Results
                        <Badge className="bg-purple-600 text-white ml-auto">
                          <Sparkles className="w-3 h-3 mr-1" />
                          AI-Powered
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      
                      {/* Risk Score */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-gray-700">Risk Score</span>
                          <Badge className={`${riskLevelColors[selectedApp.ai_risk_level]} border text-sm px-3 py-1`}>
                            {selectedApp.ai_risk_level.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="relative">
                          {/* Progress bar values are typically 0-100. If 100 is low risk, and 0 is high risk, then `value` should be `ai_risk_score`.
                              If lower score means lower risk (as stated in the description), then 0 is good, 100 is bad.
                              Let's assume the component expects value=100 for full progress. If score 0 is best, score 100 is worst:
                              So if ai_risk_score is 0, value = 100
                              If ai_risk_score is 100, value = 0.
                              This means progress would represent "safety" or "low risk".
                              Alternatively, if value represents "risk", then value=ai_risk_score.
                              The current component structure implies `value={100 - selectedApp.ai_risk_score}` where lower scores are better.
                              Let's keep it consistent with the outline's original thought. */}
                          <Progress 
                            value={selectedApp.ai_risk_score ? (100 - selectedApp.ai_risk_score) : 0} 
                            className="h-3"
                          />
                          <span className="absolute right-0 -top-6 text-xl font-bold text-gray-900">
                            {selectedApp.ai_risk_score}/100
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">
                          Lower scores indicate lower risk
                        </p>
                      </div>

                      {/* Summary */}
                      <div className="bg-white rounded-lg p-4 border border-purple-200">
                        <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                          <FileText className="w-4 h-4 text-purple-600" />
                          AI Summary
                        </h4>
                        <p className="text-sm text-gray-700 leading-relaxed">
                          {selectedApp.ai_screening_summary}
                        </p>
                      </div>

                      {/* Red Flags */}
                      {selectedApp.ai_red_flags && selectedApp.ai_red_flags.length > 0 && (
                        <div className="bg-red-50 rounded-lg p-4 border border-red-200">
                          <h4 className="font-semibold text-red-900 mb-2 flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4" />
                            Red Flags Identified
                          </h4>
                          <ul className="space-y-1">
                            {selectedApp.ai_red_flags.map((flag, index) => (
                              <li key={index} className="text-sm text-red-800 flex items-start gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 flex-shrink-0"></span>
                                {flag}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Positive Factors */}
                      {selectedApp.ai_positive_factors && selectedApp.ai_positive_factors.length > 0 && (
                        <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                          <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
                            <CheckCircle className="w-4 h-4" />
                            Positive Factors
                          </h4>
                          <ul className="space-y-1">
                            {selectedApp.ai_positive_factors.map((factor, index) => (
                              <li key={index} className="text-sm text-green-800 flex items-start gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 flex-shrink-0"></span>
                                {factor}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Manual Review Required */}
                      {selectedApp.requires_manual_review && selectedApp.manual_review_reasons && (
                        <Alert className="bg-orange-50 border-orange-300">
                          <Flag className="h-4 w-4 text-orange-600" />
                          <AlertDescription>
                            <strong className="text-orange-900">Manual Review Required</strong>
                            <ul className="mt-2 space-y-1">
                              {selectedApp.manual_review_reasons.map((reason, index) => (
                                <li key={index} className="text-sm text-orange-800">• {reason}</li>
                              ))}
                            </ul>
                          </AlertDescription>
                        </Alert>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* Application Details Card */}
                <Card className="bg-white border-0 shadow-lg">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-2xl">{selectedApp.tenant_full_name}</CardTitle>
                        <p className="text-gray-600 mt-1">{selectedApp.property_address}</p>
                      </div>
                      <Badge className={`${statusColors[selectedApp.status]} text-sm px-3 py-1`}>
                        {selectedApp.status.replace('_', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    
                    {/* Contact Information */}
                    <div>
                      <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                        <Mail className="w-5 h-5 text-blue-600" />
                        Contact Information
                      </h3>
                      <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Email:</span>
                          <p className="text-gray-900">{selectedApp.tenant_email}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Phone:</span>
                          <p className="text-gray-900">{selectedApp.tenant_phone}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Date of Birth:</span>
                          <p className="text-gray-900">{selectedApp.date_of_birth}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Current Address:</span>
                          <p className="text-gray-900">{selectedApp.current_address}</p>
                        </div>
                      </div>
                    </div>

                    {/* Lease Details */}
                    <div>
                      <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                        <Home className="w-5 h-5 text-green-600" />
                        Lease Details
                      </h3>
                      <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Move-In Date:</span>
                          <p className="text-gray-900">{selectedApp.lease_start_date}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Lease Term:</span>
                          <p className="text-gray-900">{selectedApp.lease_term_months} months</p>
                        </div>
                        {selectedApp.monthly_rent && (
                          <div>
                            <span className="font-medium text-gray-700">Monthly Rent:</span>
                            <p className="text-gray-900 text-green-600 font-semibold">
                              ${selectedApp.monthly_rent}
                            </p>
                          </div>
                        )}
                        {selectedApp.pets && (
                          <div className="md:col-span-2">
                            <span className="font-medium text-gray-700">Pets:</span>
                            <p className="text-gray-900">{selectedApp.pet_details}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Employment */}
                    <div>
                      <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                        <Briefcase className="w-5 h-5 text-purple-600" />
                        Employment Information
                      </h3>
                      <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Status:</span>
                          <p className="text-gray-900 capitalize">{selectedApp.employment_status}</p>
                        </div>
                        {selectedApp.employer_name && (
                          <div>
                            <span className="font-medium text-gray-700">Employer:</span>
                            <p className="text-gray-900">{selectedApp.employer_name}</p>
                          </div>
                        )}
                        {selectedApp.monthly_income && (
                          <div>
                            <span className="font-medium text-gray-700">Monthly Income:</span>
                            <p className="text-gray-900 text-green-600 font-semibold">
                              ${selectedApp.monthly_income.toLocaleString()}
                            </p>
                          </div>
                        )}
                        {selectedApp.monthly_rent && selectedApp.monthly_income && (
                          <div>
                            <span className="font-medium text-gray-700">Income-to-Rent Ratio:</span>
                            <p className="text-gray-900 font-semibold">
                              {(selectedApp.monthly_income / selectedApp.monthly_rent).toFixed(2)}x
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* References */}
                    {selectedApp.references && selectedApp.references.length > 0 && (
                      <div>
                        <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                          <Users className="w-5 h-5 text-orange-600" />
                          References
                        </h3>
                        <div className="space-y-3">
                          {selectedApp.references.map((ref, index) => (
                            ref.name && (
                              <div key={index} className="p-3 bg-gray-50 rounded-lg text-sm">
                                <p className="font-medium text-gray-900">{ref.name}</p>
                                <p className="text-gray-600">{ref.relationship}</p>
                                <div className="flex gap-4 mt-1 text-gray-600">
                                  {ref.phone && <span>{ref.phone}</span>}
                                  {ref.email && <span>{ref.email}</span>}
                                </div>
                              </div>
                            )
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Emergency Contact */}
                    {selectedApp.emergency_contact && selectedApp.emergency_contact.name && (
                      <div>
                        <h3 className="font-semibold text-lg mb-3">Emergency Contact</h3>
                        <div className="p-3 bg-gray-50 rounded-lg text-sm">
                          <p className="font-medium text-gray-900">{selectedApp.emergency_contact.name}</p>
                          <p className="text-gray-600">{selectedApp.emergency_contact.relationship}</p>
                          <p className="text-gray-600">{selectedApp.emergency_contact.phone}</p>
                        </div>
                      </div>
                    )}

                    {/* Landlord Notes */}
                    {selectedApp.status !== 'approved' && selectedApp.status !== 'rejected' && (
                      <div>
                        <Label htmlFor="landlord_notes">Your Notes</Label>
                        <Textarea
                          id="landlord_notes"
                          value={landlordNotes}
                          onChange={(e) => setLandlordNotes(e.target.value)}
                          placeholder="Add notes about this application..."
                          rows={3}
                        />
                      </div>
                    )}

                    {/* Rejection Reason */}
                    {selectedApp.status === 'under_review' && (
                      <div>
                        <Label htmlFor="rejection_reason">Rejection Reason (if rejecting)</Label>
                        <Textarea
                          id="rejection_reason"
                          value={rejectionReason}
                          onChange={(e) => setRejectionReason(e.target.value)}
                          placeholder="Required if rejecting the application..."
                          rows={3}
                        />
                      </div>
                    )}

                    {/* Existing Notes */}
                    {selectedApp.landlord_notes && (
                      <Alert>
                        <AlertDescription>
                          <strong>Previous Notes:</strong> {selectedApp.landlord_notes}
                        </AlertDescription>
                      </Alert>
                    )}

                    {selectedApp.rejection_reason && (
                      <Alert variant="destructive">
                        <AlertDescription>
                          <strong>Rejection Reason:</strong> {selectedApp.rejection_reason}
                        </AlertDescription>
                      </Alert>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-4 border-t">
                      {selectedApp.status === 'submitted' && (
                        <Button
                          onClick={() => handleReview(selectedApp.id)}
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Mark Under Review
                        </Button>
                      )}
                      
                      {selectedApp.status === 'under_review' && (
                        <>
                          <Button
                            onClick={() => handleApprove(selectedApp.id)}
                            className="flex-1 bg-green-600 hover:bg-green-700"
                          >
                            <ThumbsUp className="w-4 h-4 mr-2" />
                            Approve Application
                          </Button>
                          <Button
                            onClick={() => handleReject(selectedApp.id)}
                            variant="destructive"
                            className="flex-1"
                          >
                            <ThumbsDown className="w-4 h-4 mr-2" />
                            Reject Application
                          </Button>
                        </>
                      )}

                      {selectedApp.status === 'approved' && (
                        <Alert className="bg-green-50 border-green-200">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <AlertDescription className="text-green-800">
                            Application approved on {format(new Date(selectedApp.approved_date), 'MMM d, yyyy')}
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="bg-white border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Select an application to view details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
