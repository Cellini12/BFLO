import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useUser } from "@/components/hooks/useUser";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Home,
  FileText,
  Wrench,
  CreditCard,
  MessageSquare,
  Calendar,
  CheckCircle,
  Send,
  DollarSign,
  Clock,
  AlertCircle,
  Download,
  User
} from "lucide-react";
import { format, addMonths, differenceInDays } from "date-fns";

export default function TenantPortal() {
  const { user, isLoading: isUserLoading } = useUser();
  const [portalAccess, setPortalAccess] = useState(null);
  const [lease, setLease] = useState(null);
  const [payments, setPayments] = useState([]);
  const [messages, setMessages] = useState([]);
  const [maintenanceRequests, setMaintenanceRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  // Form states
  const [maintenanceForm, setMaintenanceForm] = useState({
    title: "",
    description: "",
    service_type: "",
    priority: "medium"
  });
  const [messageForm, setMessageForm] = useState({
    subject: "",
    message: "",
    priority: "normal"
  });
  const [paymentForm, setPaymentForm] = useState({
    amount: "",
    payment_method: "bank_transfer",
    payment_for_month: ""
  });

  useEffect(() => {
    if (user) {
      loadTenantData();
    }
  }, [user]);

  const loadTenantData = async () => {
    if (!user) return;
    setIsLoading(true);
    try {
      // Find portal access for this tenant
      const accessRecords = await base44.entities.TenantPortalAccess.filter(
        { tenant_email: user.email, is_active: true },
        "-created_date",
        1
      );
      
      if (accessRecords.length === 0) {
        setIsLoading(false);
        return;
      }

      const access = accessRecords[0];
      setPortalAccess(access);

      // Load lease document
      if (access.lease_document_id) {
        const leaseDoc = await base44.entities.LeaseDocument.get(access.lease_document_id);
        setLease(leaseDoc);
      }

      // Load payments
      const tenantPayments = await base44.entities.RentPayment.filter(
        { tenant_email: user.email },
        "-payment_date",
        50
      );
      setPayments(tenantPayments);

      // Load maintenance requests (jobs)
      const tenantJobs = await base44.entities.Job.filter(
        { customer_id: user.id },
        "-created_date",
        50
      );
      setMaintenanceRequests(tenantJobs);

      // Load messages
      const tenantMessages = await base44.entities.TenantMessage.filter(
        { tenant_portal_access_id: access.id },
        "-created_date",
        50
      );
      setMessages(tenantMessages);

      // Update last login
      await base44.entities.TenantPortalAccess.update(access.id, {
        last_login: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error loading tenant data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitMaintenanceRequest = async (e) => {
    e.preventDefault();
    try {
      await base44.entities.Job.create({
        ...maintenanceForm,
        customer_id: user.id,
        property_address: portalAccess.property_address,
        status: "pending",
        request_type: "standard"
      });

      // Send notification to landlord
      await base44.integrations.Core.SendEmail({
        to: portalAccess.landlord_id,
        subject: `New Maintenance Request - ${portalAccess.property_address}`,
        body: `New maintenance request from ${user.full_name}:\n\n${maintenanceForm.title}\n\n${maintenanceForm.description}`
      });

      setMaintenanceForm({
        title: "",
        description: "",
        service_type: "",
        priority: "medium"
      });
      await loadTenantData();
      alert("Maintenance request submitted successfully!");
    } catch (error) {
      console.error("Error submitting maintenance request:", error);
      alert("Failed to submit request. Please try again.");
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    try {
      await base44.entities.TenantMessage.create({
        tenant_portal_access_id: portalAccess.id,
        landlord_id: portalAccess.landlord_id,
        sender_type: "tenant",
        sender_name: user.full_name,
        ...messageForm
      });

      setMessageForm({
        subject: "",
        message: "",
        priority: "normal"
      });
      await loadTenantData();
      alert("Message sent successfully!");
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message. Please try again.");
    }
  };

  const handleSubmitPayment = async (e) => {
    e.preventDefault();
    try {
      await base44.entities.RentPayment.create({
        tenant_portal_access_id: portalAccess.id,
        landlord_id: portalAccess.landlord_id,
        tenant_email: user.email,
        property_address: portalAccess.property_address,
        amount: parseFloat(paymentForm.amount),
        payment_date: new Date().toISOString(),
        payment_for_month: paymentForm.payment_for_month,
        payment_method: paymentForm.payment_method,
        status: "completed"
      });

      setPaymentForm({
        amount: "",
        payment_method: "bank_transfer",
        payment_for_month: ""
      });
      await loadTenantData();
      alert("Payment recorded successfully!");
    } catch (error) {
      console.error("Error recording payment:", error);
      alert("Failed to record payment. Please try again.");
    }
  };

  if (isUserLoading || isLoading) {
    return (
      <div className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
        <div className="animate-pulse space-y-4 max-w-7xl mx-auto">
          <div className="h-10 w-1/3 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  if (!portalAccess) {
    return (
      <div className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
        <div className="max-w-2xl mx-auto mt-20">
          <Alert className="bg-yellow-50 border-yellow-200">
            <AlertCircle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <strong>No Active Tenant Portal Access</strong>
              <p className="mt-2">You don't currently have access to a tenant portal. Please contact your landlord to get set up.</p>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const daysUntilLeaseEnd = differenceInDays(new Date(portalAccess.lease_end_date), new Date());
  const nextPaymentDue = new Date(new Date().getFullYear(), new Date().getMonth(), portalAccess.rent_due_day);
  if (nextPaymentDue < new Date()) {
    nextPaymentDue.setMonth(nextPaymentDue.getMonth() + 1);
  }
  const daysUntilPayment = differenceInDays(nextPaymentDue, new Date());

  const thisMonthPayments = payments.filter(p => {
    const paymentDate = new Date(p.payment_date);
    const now = new Date();
    return paymentDate.getMonth() === now.getMonth() && paymentDate.getFullYear() === now.getFullYear();
  });

  const totalPaidThisMonth = thisMonthPayments.reduce((sum, p) => sum + (p.status === 'completed' ? p.amount : 0), 0);
  const rentOwed = portalAccess.monthly_rent - totalPaidThisMonth;

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl p-8 shadow-2xl">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">Welcome, {user.full_name}!</h1>
              <p className="text-blue-100 flex items-center gap-2">
                <Home className="w-5 h-5" />
                {portalAccess.property_address}
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-blue-100">Lease Ends</div>
              <div className="text-2xl font-bold">{format(new Date(portalAccess.lease_end_date), 'MMM d, yyyy')}</div>
              <div className="text-sm text-blue-100">{daysUntilLeaseEnd} days remaining</div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Monthly Rent</p>
                  <p className="text-3xl font-bold text-gray-900">${portalAccess.monthly_rent}</p>
                  <p className="text-sm text-gray-500 mt-1">Due on {portalAccess.rent_due_day}{portalAccess.rent_due_day === 1 ? 'st' : portalAccess.rent_due_day === 2 ? 'nd' : portalAccess.rent_due_day === 3 ? 'rd' : 'th'} of month</p>
                </div>
                <DollarSign className="w-12 h-12 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Amount Owed</p>
                  <p className="text-3xl font-bold text-gray-900">${rentOwed.toFixed(2)}</p>
                  <p className="text-sm text-gray-500 mt-1">Due in {daysUntilPayment} days</p>
                </div>
                <Clock className="w-12 h-12 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Requests</p>
                  <p className="text-3xl font-bold text-gray-900">
                    {maintenanceRequests.filter(r => !['completed', 'cancelled'].includes(r.status)).length}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">Maintenance items</p>
                </div>
                <Wrench className="w-12 h-12 text-blue-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white p-1 shadow-md">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Home className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="lease" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Lease
            </TabsTrigger>
            <TabsTrigger value="maintenance" className="flex items-center gap-2">
              <Wrench className="w-4 h-4" />
              Maintenance
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Messages
              {messages.filter(m => !m.is_read && m.sender_type === 'landlord').length > 0 && (
                <Badge className="bg-red-600 text-white ml-1">
                  {messages.filter(m => !m.is_read && m.sender_type === 'landlord').length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-orange-600" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {maintenanceRequests.slice(0, 3).map((request) => (
                      <div key={request.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <Wrench className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{request.title}</p>
                          <p className="text-sm text-gray-600">{format(new Date(request.created_date), 'MMM d, yyyy')}</p>
                        </div>
                        <Badge className={request.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}>
                          {request.status}
                        </Badge>
                      </div>
                    ))}
                    {maintenanceRequests.length === 0 && (
                      <p className="text-gray-500 text-center py-4">No maintenance requests yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-green-600" />
                    Recent Payments
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {payments.slice(0, 3).map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{payment.payment_for_month}</p>
                          <p className="text-sm text-gray-600">{format(new Date(payment.payment_date), 'MMM d, yyyy')}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-green-600">${payment.amount}</p>
                          <Badge className={payment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                            {payment.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {payments.length === 0 && (
                      <p className="text-gray-500 text-center py-4">No payment history yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Lease Tab */}
          <TabsContent value="lease">
            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Lease Agreement</CardTitle>
                <CardDescription>Your current lease details and document</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {lease ? (
                  <>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label className="text-gray-600">Lease Period</Label>
                        <p className="text-lg font-semibold">{format(new Date(lease.lease_start_date), 'MMM d, yyyy')} - {format(new Date(lease.lease_end_date), 'MMM d, yyyy')}</p>
                      </div>
                      <div>
                        <Label className="text-gray-600">Monthly Rent</Label>
                        <p className="text-lg font-semibold">${lease.monthly_rent}</p>
                      </div>
                      <div>
                        <Label className="text-gray-600">Security Deposit</Label>
                        <p className="text-lg font-semibold">${lease.security_deposit}</p>
                      </div>
                      <div>
                        <Label className="text-gray-600">Lease Term</Label>
                        <p className="text-lg font-semibold">{lease.lease_term_months} months</p>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="font-semibold text-gray-900 mb-4">Full Lease Document</h3>
                      <div className="bg-gray-50 p-6 rounded-lg max-h-96 overflow-y-auto">
                        <pre className="whitespace-pre-wrap text-sm text-gray-800 font-sans">
                          {lease.generated_content}
                        </pre>
                      </div>
                      <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                        <Download className="w-4 h-4 mr-2" />
                        Download Lease PDF
                      </Button>
                    </div>
                  </>
                ) : (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      No lease document available. Please contact your landlord.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Maintenance Tab */}
          <TabsContent value="maintenance" className="space-y-6">
            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Submit Maintenance Request</CardTitle>
                <CardDescription>Report an issue or request service for your property</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitMaintenanceRequest} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Issue Title *</Label>
                    <Input
                      id="title"
                      value={maintenanceForm.title}
                      onChange={(e) => setMaintenanceForm({...maintenanceForm, title: e.target.value})}
                      placeholder="e.g., Leaking faucet in bathroom"
                      required
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="service_type">Service Type</Label>
                      <Select value={maintenanceForm.service_type} onValueChange={(value) => setMaintenanceForm({...maintenanceForm, service_type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="plumbing">Plumbing</SelectItem>
                          <SelectItem value="electrical">Electrical</SelectItem>
                          <SelectItem value="hvac">HVAC</SelectItem>
                          <SelectItem value="general_maintenance">General Maintenance</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="priority">Priority</Label>
                      <Select value={maintenanceForm.priority} onValueChange={(value) => setMaintenanceForm({...maintenanceForm, priority: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      value={maintenanceForm.description}
                      onChange={(e) => setMaintenanceForm({...maintenanceForm, description: e.target.value})}
                      placeholder="Please describe the issue in detail..."
                      rows={4}
                      required
                    />
                  </div>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    <Send className="w-4 h-4 mr-2" />
                    Submit Request
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Your Maintenance Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {maintenanceRequests.map((request) => (
                    <div key={request.id} className="p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{request.title}</h4>
                          <p className="text-sm text-gray-600 mt-1">{request.description}</p>
                          <div className="flex items-center gap-3 mt-2 text-sm text-gray-500">
                            <span>{format(new Date(request.created_date), 'MMM d, yyyy')}</span>
                            <span>•</span>
                            <span className="capitalize">{request.service_type?.replace('_', ' ')}</span>
                          </div>
                        </div>
                        <Badge className={
                          request.status === 'completed' ? 'bg-green-100 text-green-800' :
                          request.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                          request.status === 'scheduled' ? 'bg-purple-100 text-purple-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {request.status.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {maintenanceRequests.length === 0 && (
                    <p className="text-center text-gray-500 py-8">No maintenance requests yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-6">
            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Record Rent Payment</CardTitle>
                <CardDescription>Record your rent payment details</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitPayment} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="amount">Amount *</Label>
                      <Input
                        id="amount"
                        type="number"
                        value={paymentForm.amount}
                        onChange={(e) => setPaymentForm({...paymentForm, amount: e.target.value})}
                        placeholder={portalAccess.monthly_rent.toString()}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="payment_for_month">Payment For Month *</Label>
                      <Input
                        id="payment_for_month"
                        value={paymentForm.payment_for_month}
                        onChange={(e) => setPaymentForm({...paymentForm, payment_for_month: e.target.value})}
                        placeholder="e.g., January 2025"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="payment_method">Payment Method</Label>
                    <Select value={paymentForm.payment_method} onValueChange={(value) => setPaymentForm({...paymentForm, payment_method: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                        <SelectItem value="credit_card">Credit Card</SelectItem>
                        <SelectItem value="debit_card">Debit Card</SelectItem>
                        <SelectItem value="check">Check</SelectItem>
                        <SelectItem value="cash">Cash</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="bg-green-600 hover:bg-green-700">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Record Payment
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {payments.map((payment) => (
                    <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">{payment.payment_for_month}</p>
                        <p className="text-sm text-gray-600">{format(new Date(payment.payment_date), 'MMM d, yyyy')} • {payment.payment_method.replace('_', ' ')}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600 text-lg">${payment.amount}</p>
                        <Badge className={payment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                          {payment.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {payments.length === 0 && (
                    <p className="text-center text-gray-500 py-8">No payment history yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6">
            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Send Message to Landlord</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSendMessage} className="space-y-4">
                  <div>
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      value={messageForm.subject}
                      onChange={(e) => setMessageForm({...messageForm, subject: e.target.value})}
                      placeholder="Message subject"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      value={messageForm.message}
                      onChange={(e) => setMessageForm({...messageForm, message: e.target.value})}
                      placeholder="Type your message here..."
                      rows={5}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="priority">Priority</Label>
                    <Select value={messageForm.priority} onValueChange={(value) => setMessageForm({...messageForm, priority: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Message History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div key={message.id} className={`p-4 rounded-lg ${message.sender_type === 'tenant' ? 'bg-blue-50 ml-8' : 'bg-gray-50 mr-8'}`}>
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-semibold text-gray-900">{message.subject}</p>
                          <p className="text-xs text-gray-500">{message.sender_name} • {format(new Date(message.created_date), 'MMM d, yyyy h:mm a')}</p>
                        </div>
                        {message.priority !== 'normal' && (
                          <Badge className={message.priority === 'urgent' ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800'}>
                            {message.priority}
                          </Badge>
                        )}
                      </div>
                      <p className="text-gray-700 text-sm">{message.message}</p>
                    </div>
                  ))}
                  {messages.length === 0 && (
                    <p className="text-center text-gray-500 py-8">No messages yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}