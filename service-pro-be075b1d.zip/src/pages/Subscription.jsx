
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Check, Star, Loader2, Shield, Zap, Crown, Building, Home, Calendar, Wrench, DollarSign, Clock, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const SUBSCRIPTION_PLANS = [
  {
    id: 'basic',
    name: 'Basic',
    tagline: 'Pay-As-You-Go',
    price_monthly: 0,
    price_annual: 0,
    tier_level: 1,
    target_user: 'Perfect for occasional service needs',
    is_most_popular: false,
    maintenance_visits_per_year: 0,
    priority_scheduling: false,
    repair_discount: 0,
    features: [
      'Submit up to 3 service requests per month',
      'Basic job status tracking',
      'Emergency support access (24/7)',
      'Email notifications',
      'Mobile-responsive portal',
      'Standard pricing on all services'
    ],
    service_inclusions: []
  },
  {
    id: 'essential',
    name: 'Essential',
    tagline: 'Peace of Mind Protection',
    price_monthly: 58,
    price_annual: 580,
    tier_level: 2,
    target_user: 'Best for homeowners with regular maintenance needs',
    is_most_popular: false,
    maintenance_visits_per_year: 2,
    priority_scheduling: true,
    repair_discount: 5,
    features: [
      'Everything in Basic',
      'Unlimited service requests',
      '2 preventive maintenance visits per year',
      '5% discount on all repairs',
      'Priority scheduling (within 48 hours)',
      'Seasonal HVAC inspections (spring & fall)',
      'Advanced job tracking with timeline',
      'Smart maintenance reminders',
      'Secure payment processing',
      'Photo uploads for service requests',
      'Referral program access'
    ],
    service_inclusions: [
      'Spring HVAC inspection',
      'Fall furnace inspection',
      'Electrical safety inspection'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    tagline: 'Complete Home Care',
    price_monthly: 91,
    price_annual: 910,
    tier_level: 3,
    target_user: 'Ideal for serious homeowners & small landlords',
    is_most_popular: true,
    maintenance_visits_per_year: 4,
    priority_scheduling: true,
    repair_discount: 10,
    features: [
      'Everything in Essential',
      '4 preventive maintenance visits per year',
      '10% discount on all repairs',
      'Priority scheduling (within 24 hours)',
      'AI-powered instant quote generation',
      'Home health score monitoring',
      'Quarterly system inspections',
      'Advanced predictive maintenance alerts',
      'AI troubleshooting assistant',
      'Local partnership discounts (up to 20%)',
      'Live progress photo uploads',
      'Detailed analytics & reporting',
      'Cumulative job bundling for efficiency',
      'Multi-property support (up to 3 properties)',
      'Annual roof & gutter inspection',
      'Water heater maintenance',
      'Smoke & CO detector testing'
    ],
    service_inclusions: [
      'All Essential services',
      'Quarterly comprehensive home inspections',
      'Annual roof & gutter inspection',
      'Water heater flush & inspection',
      'Dryer vent cleaning',
      'Smoke & CO detector testing',
      'Window & door weatherstripping check'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    tagline: 'Property Management Solution',
    price_monthly: 171,
    price_annual: 1710,
    tier_level: 4,
    target_user: 'For property management companies & serious landlords',
    is_most_popular: false,
    maintenance_visits_per_year: 6,
    priority_scheduling: true,
    repair_discount: 15,
    features: [
      'Everything in Pro',
      '6 preventive maintenance visits per year',
      '15% discount on all repairs',
      'Same-day priority scheduling',
      'Unlimited property management',
      'Professional on-site property evaluations',
      'Bi-monthly property health reports', // Changed from Monthly
      'Advanced multi-property analytics',
      'Dedicated account manager',
      'Bulk service scheduling & coordination',
      'Tenant communication tools',
      'Custom API integrations available',
      'White-label portal options',
      'Quarterly business reviews',
      'Priority emergency response (2-hour)',
      'Custom reporting & insights',
      'Turnover cleaning included',
      '24/7 emergency dispatch line'
    ],
    service_inclusions: [
      'All Pro services',
      'Bi-monthly property walkthroughs', // Changed from Monthly
      'Seasonal deep maintenance',
      'Emergency repair coverage',
      'Tenant move-in/move-out inspections',
      'Appliance maintenance program',
      'Landscaping coordination',
      'Snow removal coordination (seasonal)'
    ]
  }
];

export default function Subscription() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  const [isAnnual, setIsAnnual] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPlan = async (plan) => {
    setIsUpdating(true);
    setUpdateSuccess(false);
    try {
      await base44.auth.updateMe({
        subscription_plan: plan.id,
        subscription_status: 'active',
        subscription_tier: plan.tier_level
      });
      await loadData();
      setUpdateSuccess(true);
      setTimeout(() => setUpdateSuccess(false), 3000);
    } catch (error) {
      console.error("Error updating subscription:", error);
    } finally {
      setIsUpdating(false);
    }
  };
  
  const getDisplayPrice = (plan) => {
    if (isAnnual && plan.price_annual) {
      const annualSavings = (plan.price_monthly * 12) - plan.price_annual;
      return {
        price: plan.price_annual,
        period: '/ year',
        monthly: (plan.price_annual / 12),
        savings: annualSavings
      };
    }
    if(plan.price_monthly === 0) {
      return { price: 'Free', period: '', monthly: null, savings: 0};
    }
    return {
      price: plan.price_monthly,
      period: '/ month',
      monthly: null,
      savings: 0
    };
  };

  const calculateAnnualSavings = (plan) => {
    if (plan.price_monthly === 0) return 0;
    
    // Average repair cost: $350
    // Average number of repairs per year: 3
    const avgRepairCost = 350;
    const avgRepairsPerYear = 3;
    const totalRepairCost = avgRepairCost * avgRepairsPerYear;
    const discountSavings = totalRepairCost * (plan.repair_discount / 100);
    
    // Value of preventive maintenance (prevents 1 major repair = $800)
    const preventiveValue = plan.maintenance_visits_per_year > 0 ? 800 : 0;
    
    const annualPlanCost = isAnnual ? plan.price_annual : (plan.price_monthly * 12);
    const totalValue = discountSavings + preventiveValue;
    
    return Math.round(totalValue - annualPlanCost);
  };
  
  if (isLoading) {
    return (
      <div className="p-8 bg-gray-100 min-h-screen">
        <div className="animate-pulse space-y-8 max-w-7xl mx-auto">
          <div className="h-24 w-2/3 bg-gray-200 rounded mx-auto"></div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="h-96 bg-gray-200 rounded-xl"></div>
            <div className="h-96 bg-gray-200 rounded-xl"></div>
            <div className="h-96 bg-gray-200 rounded-xl"></div>
            <div className="h-96 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-gray-50 via-yellow-50 to-orange-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg">
              <Crown className="w-9 h-9 text-black" />
            </div>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
              Home Maintenance Plans
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
            Protect your home, prevent costly repairs, and enjoy peace of mind with our comprehensive maintenance subscription plans.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-gray-700">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-600" />
              <span>Preventive Maintenance</span>
            </div>
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              <span>Save on Repairs</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-green-600" />
              <span>Priority Scheduling</span>
            </div>
            <div className="flex items-center gap-2">
              <Wrench className="w-5 h-5 text-green-600" />
              <span>Regular Inspections</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-4 mb-8 mt-8">
            <span className={`text-sm ${!isAnnual ? 'font-semibold text-gray-900' : 'text-gray-600'}`}>
              Monthly
            </span>
            <Switch
              checked={isAnnual}
              onCheckedChange={setIsAnnual}
            />
            <span className={`text-sm ${isAnnual ? 'font-semibold text-gray-900' : 'text-gray-600'}`}>
              Annual
            </span>
            {isAnnual && (
              <Badge className="border-green-500 bg-green-100 text-green-700 ml-2">
                Save up to $298/year
              </Badge>
            )}
          </div>

          <Alert className="max-w-4xl mx-auto bg-blue-50 border-blue-300 mb-8">
            <AlertCircle className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-blue-900">
              <strong>Why Maintenance Plans?</strong> Regular preventive maintenance can prevent up to 80% of costly home repairs. 
              Our plans catch small issues before they become expensive emergencies, saving you thousands annually.
            </AlertDescription>
          </Alert>
        </div>

        {updateSuccess && (
          <Alert className="mb-6 max-w-4xl mx-auto bg-green-100 border-green-300 text-green-800">
            <AlertTitle>Success!</AlertTitle>
            <AlertDescription>Your subscription plan has been updated successfully.</AlertDescription>
          </Alert>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {SUBSCRIPTION_PLANS.map((plan) => {
            const pricing = getDisplayPrice(plan);
            const isCurrentPlan = user?.subscription_plan === plan.id;
            const annualSavings = calculateAnnualSavings(plan);
            
            return (
              <Card 
                key={plan.id}
                className={`flex flex-col relative transition-all duration-300 hover:shadow-2xl bg-white ${
                  plan.is_most_popular 
                    ? 'border-2 border-yellow-400 shadow-2xl ring-4 ring-yellow-100 scale-105' 
                    : 'border border-gray-200 hover:border-yellow-300 hover:scale-102'
                } ${isCurrentPlan ? 'ring-2 ring-green-400 border-green-400' : ''}`}
              >
                {plan.is_most_popular && (
                  <Badge className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold px-4 py-2 text-sm">
                    <Star className="w-4 h-4 mr-1" />
                    Most Popular
                  </Badge>
                )}

                <CardHeader className="pb-4">
                  <div className="flex items-center gap-3 mb-2">
                    {plan.id === 'basic' && <Shield className="w-5 h-5 text-gray-600" />}
                    {plan.id === 'essential' && <Home className="w-5 h-5 text-blue-600" />}
                    {plan.id === 'pro' && <Zap className="w-5 h-5 text-yellow-600" />}
                    {plan.id === 'enterprise' && <Building className="w-5 h-5 text-gray-900" />}
                    <div>
                      <CardTitle className="text-xl font-bold text-gray-900">{plan.name}</CardTitle>
                      <p className="text-xs text-gray-500 font-medium">{plan.tagline}</p>
                    </div>
                  </div>
                  <CardDescription className="text-gray-600 text-sm">{plan.target_user}</CardDescription>
                </CardHeader>

                <CardContent className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="mb-6">
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl lg:text-4xl font-extrabold text-gray-900">
                          {typeof pricing.price === 'number' ? `$${pricing.price}` : pricing.price}
                        </span>
                        <span className="text-sm font-medium text-gray-600">{pricing.period}</span>
                      </div>
                      {pricing.monthly && (
                        <p className="text-xs text-gray-500 mt-1">
                          ${pricing.monthly.toFixed(2)}/month • Save ${pricing.savings}/year
                        </p>
                      )}
                      {annualSavings > 0 && (
                        <Badge className="mt-2 bg-green-100 text-green-800 border-green-300">
                          💰 Save ~${annualSavings.toLocaleString()}/year vs repairs
                        </Badge>
                      )}
                    </div>

                    {/* Key Stats */}
                    {plan.maintenance_visits_per_year > 0 && (
                      <div className="grid grid-cols-3 gap-2 mb-4 p-3 bg-gray-50 rounded-lg">
                        <div className="text-center">
                          <div className="text-xl font-bold text-blue-600">{plan.maintenance_visits_per_year}</div>
                          <div className="text-xs text-gray-600">Visits/Year</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-green-600">{plan.repair_discount}%</div>
                          <div className="text-xs text-gray-600">Discount</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-purple-600">
                            {plan.priority_scheduling ? <Clock className="w-5 h-5 mx-auto" /> : '-'}
                          </div>
                          <div className="text-xs text-gray-600">Priority</div>
                        </div>
                      </div>
                    )}

                    {/* Service Inclusions */}
                    {plan.service_inclusions.length > 0 && (
                      <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <h4 className="font-semibold text-sm text-blue-900 mb-2 flex items-center gap-1">
                          <Wrench className="w-4 h-4" />
                          Included Services:
                        </h4>
                        <ul className="space-y-1">
                          {plan.service_inclusions.slice(0, 3).map((service, index) => (
                            <li key={index} className="flex items-start gap-2 text-xs text-blue-800">
                              <Check className="w-3 h-3 text-blue-600 mt-0.5 flex-shrink-0" />
                              <span>{service}</span>
                            </li>
                          ))}
                          {plan.service_inclusions.length > 3 && (
                            <li className="text-xs text-blue-700 font-medium pl-5">
                              + {plan.service_inclusions.length - 3} more services
                            </li>
                          )}
                        </ul>
                      </div>
                    )}
                  
                    {/* Platform Features */}
                    <div className="mb-4">
                      <h4 className="font-semibold text-xs text-gray-700 mb-2">Platform Features:</h4>
                      <ul className="space-y-2">
                        {plan.features.slice(0, 5).map((feature, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 text-green-600 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-600 text-xs leading-relaxed">{feature}</span>
                          </li>
                        ))}
                        {plan.features.length > 5 && (
                          <li className="text-xs text-gray-500 font-medium pl-5">
                            + {plan.features.length - 5} more features
                          </li>
                        )}
                      </ul>
                    </div>
                  </div>

                  <Button 
                    onClick={() => handleSelectPlan(plan)}
                    disabled={isUpdating || isCurrentPlan}
                    className={`w-full font-semibold transition-all duration-200 ${
                      plan.is_most_popular 
                        ? 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black shadow-lg' 
                        : isCurrentPlan
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : plan.id === 'enterprise'
                        ? 'bg-gray-900 hover:bg-black text-yellow-400 hover:shadow-lg'
                        : 'bg-gray-800 hover:bg-gray-900 text-white hover:shadow-lg'
                    }`}
                  >
                    {isUpdating ? <Loader2 className="animate-spin w-4 h-4" /> : 
                     isCurrentPlan ? (
                       <>
                         <Check className="w-4 h-4 mr-2" />
                         Current Plan
                       </>
                     ) : (
                       <>
                         {plan.is_most_popular ? <Star className="w-4 h-4 mr-2" /> : <Crown className="w-4 h-4 mr-2" />}
                         Choose {plan.name}
                       </>
                     )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
        
        <div className="text-center mt-16 space-y-6">
          <div className="bg-white rounded-xl p-8 shadow-lg border border-gray-200 max-w-5xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Why Choose BFLO Contracting Maintenance Plans?</h3>
            <div className="grid md:grid-cols-3 gap-8 text-left">
              <div className="space-y-2">
                <Shield className="w-8 h-8 text-blue-600 mb-2" />
                <h4 className="font-semibold text-gray-900">Prevent Major Repairs</h4>
                <p className="text-gray-600 text-sm">Regular maintenance catches small issues before they become expensive emergencies. Save thousands on avoided repairs.</p>
              </div>
              <div className="space-y-2">
                <Calendar className="w-8 h-8 text-yellow-600 mb-2" />
                <h4 className="font-semibold text-gray-900">Priority Service</h4>
                <p className="text-gray-600 text-sm">Members get priority scheduling, faster response times, and never wait weeks for an appointment.</p>
              </div>
              <div className="space-y-2">
                <DollarSign className="w-8 h-8 text-green-600 mb-2" />
                <h4 className="font-semibold text-gray-900">Guaranteed Savings</h4>
                <p className="text-gray-600 text-sm">Members save 10-20% on all repairs, plus avoid costly emergency service fees with preventive care.</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-2 text-gray-600">
            <Shield className="w-4 h-4" />
            <span className="text-sm">30-day money-back guarantee • Cancel anytime • No hidden fees</span>
          </div>
          <p className="text-xs text-gray-500">
            Note: This is a demonstration platform. No real payment will be processed.
          </p>
        </div>
      </div>
    </div>
  );
}
