import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { SupportTicket } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Bot,
  User as UserIcon
} from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  open: "bg-blue-100 text-blue-800 border-blue-200",
  in_progress: "bg-yellow-100 text-yellow-800 border-yellow-200",
  resolved: "bg-green-100 text-green-800 border-green-200",
  closed: "bg-gray-100 text-gray-800 border-gray-200"
};

export default function SupportTickets() {
  const [user, setUser] = useState(null);
  const [tickets, setTickets] = useState([]);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const currentUser = await User.me();
      const userTickets = await SupportTicket.filter({ customer_id: currentUser.id }, "-created_date");
      
      setUser(currentUser);
      setTickets(userTickets);
    } catch (error) {
      console.error("Error loading support tickets:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-16 bg-gray-200 rounded-xl"></div>
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              {[1,2,3].map(i => (
                <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
            <div className="h-64 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Support Tickets</h1>
          <p className="text-gray-600">AI-assisted support conversations and expert help</p>
        </div>

        {user?.subscription_status !== 'active' && (
          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <Bot className="w-12 h-12 text-purple-600" />
                <div>
                  <h3 className="font-semibold text-purple-900 mb-2">Upgrade for AI Support Access</h3>
                  <p className="text-purple-700 text-sm mb-4">
                    Get unlimited AI troubleshooting and direct access to human experts with a Premium subscription.
                  </p>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    Upgrade to Premium
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            {/* Tickets List */}
            <div className="space-y-4">
              {tickets.length === 0 ? (
                <Card className="bg-white/60 backdrop-blur border-0 shadow-lg">
                  <CardContent className="p-12 text-center">
                    <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No support tickets yet</h3>
                    <p className="text-gray-500 mb-4">
                      Use our AI troubleshooting assistant and submit conversations when you need expert help
                    </p>
                    <Button className="bg-green-600 hover:bg-green-700">
                      Try AI Assistant
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                tickets.map((ticket) => (
                  <Card 
                    key={ticket.id}
                    className={`bg-white/60 backdrop-blur border-0 shadow-lg hover:shadow-xl transition-all duration-200 cursor-pointer ${
                      selectedTicket?.id === ticket.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedTicket(ticket)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {ticket.issue_summary}
                          </h3>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            {ticket.created_from === 'ai_chat' ? (
                              <Bot className="w-4 h-4" />
                            ) : (
                              <UserIcon className="w-4 h-4" />
                            )}
                            <span>
                              {ticket.created_from === 'ai_chat' ? 'From AI Chat' : 'From Troubleshooting Guide'}
                            </span>
                            <span>•</span>
                            <span>{format(new Date(ticket.created_date), "MMM d, yyyy")}</span>
                          </div>
                        </div>
                        <Badge className={`${statusColors[ticket.status]} border`}>
                          {ticket.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      
                      <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 mb-4">
                        <p className="line-clamp-3">
                          {ticket.ai_conversation.substring(0, 200)}...
                        </p>
                      </div>
                      
                      {ticket.agent_response && (
                        <div className="bg-blue-50 border-l-4 border-blue-400 p-3 text-sm">
                          <p className="font-medium text-blue-800">Support Response:</p>
                          <p className="text-blue-700 line-clamp-2">{ticket.agent_response}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
          
          <div>
            {/* Ticket Details */}
            {selectedTicket ? (
              <Card className="bg-white/60 backdrop-blur border-0 shadow-lg sticky top-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Ticket Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">{selectedTicket.issue_summary}</h3>
                    <Badge className={`${statusColors[selectedTicket.status]} border`}>
                      {selectedTicket.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">AI Conversation:</h4>
                    <div className="bg-gray-50 p-3 rounded text-sm max-h-64 overflow-y-auto">
                      <pre className="whitespace-pre-wrap text-gray-700">
                        {selectedTicket.ai_conversation}
                      </pre>
                    </div>
                  </div>
                  
                  {selectedTicket.agent_response && (
                    <div>
                      <h4 className="font-semibold mb-2 text-blue-800">Expert Response:</h4>
                      <div className="bg-blue-50 border border-blue-200 p-3 rounded text-sm">
                        <p className="text-blue-800">{selectedTicket.agent_response}</p>
                      </div>
                    </div>
                  )}
                  
                  {selectedTicket.resolution_notes && (
                    <div>
                      <h4 className="font-semibold mb-2 text-green-800">Resolution Notes:</h4>
                      <div className="bg-green-50 border border-green-200 p-3 rounded text-sm">
                        <p className="text-green-800">{selectedTicket.resolution_notes}</p>
                      </div>
                    </div>
                  )}
                  
                  <div className="text-xs text-gray-500">
                    <p>Created: {format(new Date(selectedTicket.created_date), "MMM d, yyyy 'at' h:mm a")}</p>
                    <p>Priority: {selectedTicket.priority}</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-white/60 backdrop-blur border-0 shadow-lg">
                <CardContent className="p-8 text-center">
                  <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="font-semibold text-gray-900 mb-2">Select a ticket</h3>
                  <p className="text-gray-500 text-sm">Choose a support ticket to view details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}