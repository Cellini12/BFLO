import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useUser } from "@/components/hooks/useUser";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Home,
  CheckCircle,
  Upload,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Droplets,
  Zap,
  Wind,
  Car,
  Trees,
  Wand2,
  Copy,
  RefreshCw
} from "lucide-react";

const STEPS = [
  { id: "basic", title: "Basic Info", icon: Home },
  { id: "systems", title: "Home Systems", icon: Wind },
  { id: "exterior", title: "Exterior", icon: Car },
  { id: "services", title: "Services", icon: Trees },
  { id: "listing", title: "Listing", icon: Sparkles },
  { id: "photos", title: "Photos", icon: Upload }
];

export default function PropertyOnboarding() {
  const { user, isLoading: isUserLoading } = useUser();
  const [currentStep, setCurrentStep] = useState(0);
  const [property, setProperty] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
  const [formData, setFormData] = useState({
    property_address: "",
    property_type: "single_family",
    year_built: "",
    square_footage: "",
    bedrooms: "",
    bathrooms: "",
    lot_size: "",
    roof_type: "",
    roof_last_replaced: "",
    hvac_type: "",
    hvac_last_serviced: "",
    hvac_age_years: "",
    water_heater_type: "",
    water_heater_age_years: "",
    plumbing_last_updated: "",
    electrical_last_updated: "",
    electrical_panel_amps: "",
    driveway_type: "",
    driveway_last_sealed: "",
    has_landscaping_service: false,
    needs_landscaping_service: false,
    landscaping_service_provider: "",
    basement_type: "",
    has_sump_pump: false,
    foundation_type: "",
    windows_last_replaced: "",
    special_features: [],
    notes: "",
    listing_description: "",
    listing_highlights: []
  });

  useEffect(() => {
    if (user) {
      loadProperty();
    }
  }, [user]);

  const loadProperty = async () => {
    if (!user) return;
    try {
      const properties = await base44.entities.Property.filter(
        { owner_id: user.id },
        "-created_date",
        1
      );
      
      if (properties.length > 0) {
        const existingProperty = properties[0];
        setProperty(existingProperty);
        setFormData({
          property_address: existingProperty.property_address || "",
          property_type: existingProperty.property_type || "single_family",
          year_built: existingProperty.year_built?.toString() || "",
          square_footage: existingProperty.square_footage?.toString() || "",
          bedrooms: existingProperty.bedrooms?.toString() || "",
          bathrooms: existingProperty.bathrooms?.toString() || "",
          lot_size: existingProperty.lot_size?.toString() || "",
          roof_type: existingProperty.roof_type || "",
          roof_last_replaced: existingProperty.roof_last_replaced || "",
          hvac_type: existingProperty.hvac_type || "",
          hvac_last_serviced: existingProperty.hvac_last_serviced || "",
          hvac_age_years: existingProperty.hvac_age_years?.toString() || "",
          water_heater_type: existingProperty.water_heater_type || "",
          water_heater_age_years: existingProperty.water_heater_age_years?.toString() || "",
          plumbing_last_updated: existingProperty.plumbing_last_updated || "",
          electrical_last_updated: existingProperty.electrical_last_updated || "",
          electrical_panel_amps: existingProperty.electrical_panel_amps?.toString() || "",
          driveway_type: existingProperty.driveway_type || "",
          driveway_last_sealed: existingProperty.driveway_last_sealed || "",
          has_landscaping_service: existingProperty.has_landscaping_service || false,
          needs_landscaping_service: existingProperty.needs_landscaping_service || false,
          landscaping_service_provider: existingProperty.landscaping_service_provider || "",
          basement_type: existingProperty.basement_type || "",
          has_sump_pump: existingProperty.has_sump_pump || false,
          foundation_type: existingProperty.foundation_type || "",
          windows_last_replaced: existingProperty.windows_last_replaced || "",
          special_features: existingProperty.special_features || [],
          notes: existingProperty.notes || "",
          listing_description: existingProperty.listing_description || "",
          listing_highlights: existingProperty.listing_highlights || []
        });
      } else if (user.address) {
        setFormData(prev => ({ ...prev, property_address: user.address }));
      }
    } catch (error) {
      console.error("Error loading property:", error);
    }
  };

  const generateListingDescription = async () => {
    setIsGeneratingDescription(true);
    try {
      const propertyAge = formData.year_built ? new Date().getFullYear() - parseInt(formData.year_built) : null;
      
      const prompt = `You are a professional real estate copywriter. Create a compelling property listing description based on the following details:

Property Details:
- Address: ${formData.property_address}
- Type: ${formData.property_type?.replace('_', ' ')}
- Year Built: ${formData.year_built || 'Not specified'}
- Square Footage: ${formData.square_footage ? formData.square_footage + ' sq ft' : 'Not specified'}
- Bedrooms: ${formData.bedrooms || 'Not specified'}
- Bathrooms: ${formData.bathrooms || 'Not specified'}
- Lot Size: ${formData.lot_size ? formData.lot_size + ' acres' : 'Not specified'}
- Basement: ${formData.basement_type?.replace('_', ' ') || 'Not specified'}
- HVAC: ${formData.hvac_type?.replace('_', ' ') || 'Not specified'}
- Roof Type: ${formData.roof_type?.replace('_', ' ') || 'Not specified'}
- Driveway: ${formData.driveway_type || 'Not specified'}
- Special Features: ${formData.special_features?.length > 0 ? formData.special_features.join(', ') : 'None specified'}
- Additional Notes: ${formData.notes || 'None'}

Create:
1. A compelling 2-3 paragraph property description that highlights the best features and would appeal to potential tenants or buyers
2. A list of 5-8 key highlights/bullet points that emphasize the most attractive features
3. Use warm, inviting language while remaining professional
4. Emphasize location benefits, modern amenities, and quality features
5. If the property is older (${propertyAge ? propertyAge + ' years' : 'unknown age'}), emphasize charm, character, or recent updates rather than age

Return the response in this exact JSON format.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            description: { type: "string" },
            highlights: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setFormData(prev => ({
        ...prev,
        listing_description: result.description,
        listing_highlights: result.highlights
      }));

    } catch (error) {
      console.error("Error generating description:", error);
      alert("Failed to generate listing description. Please try again.");
    } finally {
      setIsGeneratingDescription(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copied to clipboard!");
  };

  const calculateProgress = () => {
    const totalFields = Object.keys(formData).length;
    let filledFields = 0;
    for (const key in formData) {
      const value = formData[key];
      if (typeof value === 'boolean') {
        filledFields++;
      } else if (Array.isArray(value)) {
        if (value.length > 0) filledFields++;
      } else if (value !== "" && value !== null && value !== undefined) {
        filledFields++;
      }
    }
    return Math.round((filledFields / totalFields) * 100);
  };

  const parseNumberField = (value) => {
    if (value === "" || value === null || value === undefined) return null;
    const parsed = parseFloat(value);
    return isNaN(parsed) ? null : parsed;
  };

  const handleSave = async (markComplete = false) => {
    setIsSaving(true);
    try {
      const progress = calculateProgress();
      
      const dataToSave = {
        property_address: formData.property_address || null,
        property_type: formData.property_type || null,
        year_built: parseNumberField(formData.year_built),
        square_footage: parseNumberField(formData.square_footage),
        bedrooms: parseNumberField(formData.bedrooms),
        bathrooms: parseNumberField(formData.bathrooms),
        lot_size: parseNumberField(formData.lot_size),
        roof_type: formData.roof_type || null,
        roof_last_replaced: formData.roof_last_replaced || null,
        hvac_type: formData.hvac_type || null,
        hvac_last_serviced: formData.hvac_last_serviced || null,
        hvac_age_years: parseNumberField(formData.hvac_age_years),
        water_heater_type: formData.water_heater_type || null,
        water_heater_age_years: parseNumberField(formData.water_heater_age_years),
        plumbing_last_updated: formData.plumbing_last_updated || null,
        electrical_last_updated: formData.electrical_last_updated || null,
        electrical_panel_amps: parseNumberField(formData.electrical_panel_amps),
        driveway_type: formData.driveway_type || null,
        driveway_last_sealed: formData.driveway_last_sealed || null,
        has_landscaping_service: formData.has_landscaping_service,
        needs_landscaping_service: formData.needs_landscaping_service,
        landscaping_service_provider: formData.landscaping_service_provider || null,
        basement_type: formData.basement_type || null,
        has_sump_pump: formData.has_sump_pump,
        foundation_type: formData.foundation_type || null,
        windows_last_replaced: formData.windows_last_replaced || null,
        special_features: formData.special_features,
        notes: formData.notes || null,
        listing_description: formData.listing_description || null,
        listing_highlights: formData.listing_highlights,
        description_generated_date: formData.listing_description ? new Date().toISOString() : null,
        owner_id: user.id,
        onboarding_progress: progress,
        onboarding_completed: markComplete || progress === 100
      };

      if (property) {
        await base44.entities.Property.update(property.id, dataToSave);
      } else {
        const newProperty = await base44.entities.Property.create(dataToSave);
        setProperty(newProperty);
      }

      if (markComplete) {
        window.location.href = createPageUrl("Dashboard");
      }
    } catch (error) {
      console.error("Error saving property:", error);
      alert("Failed to save property data. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleNext = async () => {
    await handleSave(false);
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFinish = async () => {
    await handleSave(true);
  };

  const progress = calculateProgress();

  if (isUserLoading) {
    return (
      <div className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
        <div className="animate-pulse space-y-4 max-w-4xl mx-auto">
          <div className="h-10 w-1/3 bg-gray-200 rounded"></div>
          <div className="h-64 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">Property Profile Setup</h1>
          </div>
          <p className="text-lg text-gray-600">
            Help us understand your property to provide personalized maintenance recommendations
          </p>
        </div>

        {/* Progress Bar */}
        <Card className="bg-white border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Overall Progress</span>
              <span className="text-sm font-bold text-blue-600">{progress}%</span>
            </div>
            <Progress value={progress} className="h-3" />
          </CardContent>
        </Card>

        {/* Step Indicators */}
        <div className="flex justify-between">
          {STEPS.map((step, index) => {
            const StepIcon = step.icon;
            const isActive = index === currentStep;
            const isCompleted = index < currentStep;
            
            return (
              <div key={step.id} className="flex flex-col items-center flex-1">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                  isActive ? 'bg-blue-600 text-white scale-110' :
                  isCompleted ? 'bg-green-600 text-white' :
                  'bg-gray-200 text-gray-400'
                }`}>
                  {isCompleted ? <CheckCircle className="w-6 h-6" /> : <StepIcon className="w-6 h-6" />}
                </div>
                <span className={`text-xs mt-2 font-medium ${isActive ? 'text-blue-600' : 'text-gray-600'}`}>
                  {step.title}
                </span>
              </div>
            );
          })}
        </div>

        {/* Form Content */}
        <Card className="bg-white border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl">{STEPS[currentStep].title}</CardTitle>
            <CardDescription>Please provide as much detail as possible for accurate recommendations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Step 0: Basic Info */}
            {currentStep === 0 && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="property_address">Property Address *</Label>
                  <Input
                    id="property_address"
                    value={formData.property_address}
                    onChange={(e) => setFormData({...formData, property_address: e.target.value})}
                    placeholder="123 Main St, Buffalo, NY 14201"
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="property_type">Property Type</Label>
                    <Select value={formData.property_type} onValueChange={(value) => setFormData({...formData, property_type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single_family">Single Family</SelectItem>
                        <SelectItem value="multi_family">Multi Family</SelectItem>
                        <SelectItem value="duplex">Duplex</SelectItem>
                        <SelectItem value="townhouse">Townhouse</SelectItem>
                        <SelectItem value="condo">Condo</SelectItem>
                        <SelectItem value="apartment">Apartment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="year_built">Year Built</Label>
                    <Input
                      id="year_built"
                      type="number"
                      value={formData.year_built}
                      onChange={(e) => setFormData({...formData, year_built: e.target.value})}
                      placeholder="1985"
                    />
                  </div>
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="square_footage">Square Footage</Label>
                    <Input
                      id="square_footage"
                      type="number"
                      value={formData.square_footage}
                      onChange={(e) => setFormData({...formData, square_footage: e.target.value})}
                      placeholder="2000"
                    />
                  </div>
                  <div>
                    <Label htmlFor="bedrooms">Bedrooms</Label>
                    <Input
                      id="bedrooms"
                      type="number"
                      value={formData.bedrooms}
                      onChange={(e) => setFormData({...formData, bedrooms: e.target.value})}
                      placeholder="3"
                    />
                  </div>
                  <div>
                    <Label htmlFor="bathrooms">Bathrooms</Label>
                    <Input
                      id="bathrooms"
                      type="number"
                      step="0.5"
                      value={formData.bathrooms}
                      onChange={(e) => setFormData({...formData, bathrooms: e.target.value})}
                      placeholder="2.5"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="lot_size">Lot Size (acres)</Label>
                  <Input
                    id="lot_size"
                    type="number"
                    step="0.1"
                    value={formData.lot_size}
                    onChange={(e) => setFormData({...formData, lot_size: e.target.value})}
                    placeholder="0.25"
                  />
                </div>
              </div>
            )}

            {/* Step 1: Home Systems */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-600">
                  <div className="flex items-center gap-2 mb-2">
                    <Wind className="w-5 h-5 text-blue-600" />
                    <h3 className="font-semibold text-blue-900">HVAC System</h3>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <div>
                      <Label htmlFor="hvac_type">HVAC Type</Label>
                      <Select value={formData.hvac_type} onValueChange={(value) => setFormData({...formData, hvac_type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="central_air">Central Air</SelectItem>
                          <SelectItem value="heat_pump">Heat Pump</SelectItem>
                          <SelectItem value="ductless">Ductless Mini-Split</SelectItem>
                          <SelectItem value="window_units">Window Units</SelectItem>
                          <SelectItem value="none">None</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="hvac_age_years">System Age (years)</Label>
                      <Input
                        id="hvac_age_years"
                        type="number"
                        value={formData.hvac_age_years}
                        onChange={(e) => setFormData({...formData, hvac_age_years: e.target.value})}
                        placeholder="10"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="hvac_last_serviced">Last Serviced</Label>
                      <Input
                        id="hvac_last_serviced"
                        type="date"
                        value={formData.hvac_last_serviced}
                        onChange={(e) => setFormData({...formData, hvac_last_serviced: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-orange-50 rounded-lg border-l-4 border-orange-600">
                  <div className="flex items-center gap-2 mb-2">
                    <Droplets className="w-5 h-5 text-orange-600" />
                    <h3 className="font-semibold text-orange-900">Plumbing & Water Heater</h3>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <div>
                      <Label htmlFor="water_heater_type">Water Heater Type</Label>
                      <Select value={formData.water_heater_type} onValueChange={(value) => setFormData({...formData, water_heater_type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="tank">Tank</SelectItem>
                          <SelectItem value="tankless">Tankless</SelectItem>
                          <SelectItem value="heat_pump">Heat Pump</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="water_heater_age_years">Water Heater Age (years)</Label>
                      <Input
                        id="water_heater_age_years"
                        type="number"
                        value={formData.water_heater_age_years}
                        onChange={(e) => setFormData({...formData, water_heater_age_years: e.target.value})}
                        placeholder="8"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="plumbing_last_updated">Plumbing Last Updated</Label>
                      <Input
                        id="plumbing_last_updated"
                        type="date"
                        value={formData.plumbing_last_updated}
                        onChange={(e) => setFormData({...formData, plumbing_last_updated: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 rounded-lg border-l-4 border-yellow-600">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-5 h-5 text-yellow-600" />
                    <h3 className="font-semibold text-yellow-900">Electrical System</h3>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <div>
                      <Label htmlFor="electrical_panel_amps">Panel Amperage</Label>
                      <Select value={formData.electrical_panel_amps?.toString()} onValueChange={(value) => setFormData({...formData, electrical_panel_amps: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select amperage" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="60">60 Amps</SelectItem>
                          <SelectItem value="100">100 Amps</SelectItem>
                          <SelectItem value="150">150 Amps</SelectItem>
                          <SelectItem value="200">200 Amps</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="electrical_last_updated">Last Updated</Label>
                      <Input
                        id="electrical_last_updated"
                        type="date"
                        value={formData.electrical_last_updated}
                        onChange={(e) => setFormData({...formData, electrical_last_updated: e.target.value})}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Exterior */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="p-4 bg-purple-50 rounded-lg border-l-4 border-purple-600">
                  <h3 className="font-semibold text-purple-900 mb-3">Roof Information</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="roof_type">Roof Type</Label>
                      <Select value={formData.roof_type} onValueChange={(value) => setFormData({...formData, roof_type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="asphalt_shingles">Asphalt Shingles</SelectItem>
                          <SelectItem value="metal">Metal</SelectItem>
                          <SelectItem value="tile">Tile</SelectItem>
                          <SelectItem value="slate">Slate</SelectItem>
                          <SelectItem value="flat">Flat</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="roof_last_replaced">Last Replaced</Label>
                      <Input
                        id="roof_last_replaced"
                        type="date"
                        value={formData.roof_last_replaced}
                        onChange={(e) => setFormData({...formData, roof_last_replaced: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg border-l-4 border-gray-600">
                  <div className="flex items-center gap-2 mb-3">
                    <Car className="w-5 h-5 text-gray-600" />
                    <h3 className="font-semibold text-gray-900">Driveway</h3>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="driveway_type">Driveway Type</Label>
                      <Select value={formData.driveway_type} onValueChange={(value) => setFormData({...formData, driveway_type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="asphalt">Asphalt (Blacktop)</SelectItem>
                          <SelectItem value="concrete">Concrete</SelectItem>
                          <SelectItem value="gravel">Gravel</SelectItem>
                          <SelectItem value="paver">Paver Stones</SelectItem>
                          <SelectItem value="none">No Driveway</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {formData.driveway_type === 'asphalt' && (
                      <div>
                        <Label htmlFor="driveway_last_sealed">Last Sealed</Label>
                        <Input
                          id="driveway_last_sealed"
                          type="date"
                          value={formData.driveway_last_sealed}
                          onChange={(e) => setFormData({...formData, driveway_last_sealed: e.target.value})}
                        />
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="basement_type">Basement Type</Label>
                    <Select value={formData.basement_type} onValueChange={(value) => setFormData({...formData, basement_type: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="finished">Finished</SelectItem>
                        <SelectItem value="unfinished">Unfinished</SelectItem>
                        <SelectItem value="crawl_space">Crawl Space</SelectItem>
                        <SelectItem value="none">No Basement</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="foundation_type">Foundation Type</Label>
                    <Select value={formData.foundation_type} onValueChange={(value) => setFormData({...formData, foundation_type: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="concrete">Concrete</SelectItem>
                        <SelectItem value="stone">Stone</SelectItem>
                        <SelectItem value="block">Concrete Block</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Switch
                    checked={formData.has_sump_pump}
                    onCheckedChange={(checked) => setFormData({...formData, has_sump_pump: checked})}
                  />
                  <Label>Property has a sump pump</Label>
                </div>

                <div>
                  <Label htmlFor="windows_last_replaced">Windows Last Replaced</Label>
                  <Input
                    id="windows_last_replaced"
                    type="date"
                    value={formData.windows_last_replaced}
                    onChange={(e) => setFormData({...formData, windows_last_replaced: e.target.value})}
                  />
                </div>
              </div>
            )}

            {/* Step 3: Services */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-600">
                  <div className="flex items-center gap-2 mb-3">
                    <Trees className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-green-900">Landscaping & Lawn Care</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={formData.has_landscaping_service}
                        onCheckedChange={(checked) => setFormData({...formData, has_landscaping_service: checked})}
                      />
                      <Label>I currently have a landscaping service</Label>
                    </div>

                    {formData.has_landscaping_service && (
                      <div>
                        <Label htmlFor="landscaping_service_provider">Service Provider Name</Label>
                        <Input
                          id="landscaping_service_provider"
                          value={formData.landscaping_service_provider}
                          onChange={(e) => setFormData({...formData, landscaping_service_provider: e.target.value})}
                          placeholder="ABC Landscaping"
                        />
                      </div>
                    )}

                    <div className="flex items-center gap-3">
                      <Switch
                        checked={formData.needs_landscaping_service}
                        onCheckedChange={(checked) => setFormData({...formData, needs_landscaping_service: checked})}
                      />
                      <Label>I'm looking for landscaping/lawn care services</Label>
                    </div>

                    {formData.needs_landscaping_service && (
                      <Alert className="bg-blue-50 border-blue-200">
                        <AlertDescription className="text-blue-800">
                          ✨ We'll connect you with trusted local landscaping partners who offer special rates for BFLO Contracting customers!
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    placeholder="Any other important information about your property..."
                    rows={4}
                  />
                </div>
              </div>
            )}

            {/* Step 4: AI Listing Generation */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <Alert className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                  <Wand2 className="h-5 w-5 text-purple-600" />
                  <AlertDescription className="text-purple-900">
                    <strong>AI-Powered Listing Description</strong><br/>
                    Let our AI create a compelling property description based on the details you've provided. Perfect for rental listings, marketing materials, or property documentation!
                  </AlertDescription>
                </Alert>

                <div className="text-center py-8">
                  <Button
                    onClick={generateListingDescription}
                    disabled={isGeneratingDescription || !formData.property_address}
                    className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white text-lg px-8 py-6"
                    size="lg"
                  >
                    {isGeneratingDescription ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Generating Description...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-5 h-5 mr-2" />
                        Generate AI Description
                      </>
                    )}
                  </Button>
                  {!formData.property_address && (
                    <p className="text-sm text-gray-600 mt-2">Please complete the basic property info first</p>
                  )}
                </div>

                {formData.listing_description && (
                  <div className="space-y-6">
                    <div className="p-6 bg-white rounded-lg border-2 border-purple-200">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-lg text-gray-900">Property Description</h3>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(formData.listing_description)}
                          >
                            <Copy className="w-4 h-4 mr-1" />
                            Copy
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={generateListingDescription}
                            disabled={isGeneratingDescription}
                          >
                            <RefreshCw className="w-4 h-4 mr-1" />
                            Regenerate
                          </Button>
                        </div>
                      </div>
                      <Textarea
                        value={formData.listing_description}
                        onChange={(e) => setFormData({...formData, listing_description: e.target.value})}
                        rows={6}
                        className="text-gray-700 leading-relaxed"
                      />
                    </div>

                    {formData.listing_highlights && formData.listing_highlights.length > 0 && (
                      <div className="p-6 bg-white rounded-lg border-2 border-blue-200">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-semibold text-lg text-gray-900">Key Highlights</h3>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(formData.listing_highlights.join('\n• '))}
                          >
                            <Copy className="w-4 h-4 mr-1" />
                            Copy List
                          </Button>
                        </div>
                        <ul className="space-y-2">
                          {formData.listing_highlights.map((highlight, index) => (
                            <li key={index} className="flex items-start gap-2 text-gray-700">
                              <span className="text-blue-600 font-bold mt-1">•</span>
                              <span>{highlight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Step 5: Photos */}
            {currentStep === 5 && (
              <div className="space-y-4">
                <Alert className="bg-blue-50 border-blue-200">
                  <Upload className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    <strong>Photos help us serve you better!</strong> Upload photos of your property's exterior, roof, driveway, HVAC system, and any areas of concern. This will help our technicians prepare for service calls and provide more accurate quotes.
                  </AlertDescription>
                </Alert>

                <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Photo Upload Coming Soon</h3>
                  <p className="text-gray-600">
                    You can always add photos later from your property profile or when creating service requests.
                  </p>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={handleBack}
                disabled={currentStep === 0 || isSaving}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>

              {currentStep < STEPS.length - 1 ? (
                <Button 
                  onClick={handleNext} 
                  disabled={isSaving}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isSaving ? "Saving..." : "Next"}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button 
                  onClick={handleFinish} 
                  disabled={isSaving} 
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  {isSaving ? "Saving..." : "Complete Setup"}
                  <CheckCircle className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}