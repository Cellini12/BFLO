import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { ReferralProgram as ReferralEntity } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Share2, 
  Gift, 
  Copy, 
  Mail, 
  MessageCircle, 
  Facebook, 
  Twitter,
  DollarSign,
  Users,
  CheckCircle,
  TrendingUp,
  AlertCircle
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ReferralProgram() {
  const [user, setUser] = useState(null);
  const [referrals, setReferrals] = useState([]);
  const [referralCode, setReferralCode] = useState("");
  const [newReferralEmail, setNewReferralEmail] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [copySuccess, setCopySuccess] = useState(false);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [error, setError] = useState("");

  const generateReferralCode = (name) => {
    const firstName = name.split(' ')[0].toUpperCase();
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    return `${firstName}${randomNum}`;
  };

  const loadData = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const code = currentUser.referral_code || generateReferralCode(currentUser.full_name);
      setReferralCode(code);
      
      // Add delay and error handling for referrals
      try {
        await new Promise(resolve => setTimeout(resolve, 500)); // 500ms delay to avoid rate limits
        const userReferrals = await ReferralEntity.filter({ referrer_id: currentUser.id });
        setReferrals(userReferrals);
        
        const earnings = userReferrals
          .filter(ref => ref.status === 'rewarded')
          .reduce((sum, ref) => sum + (ref.reward_amount || 0), 0);
        setTotalEarnings(earnings);
      } catch (referralError) {
        console.error("Error loading referrals:", referralError);
        // Don't fail the whole page if referrals fail to load
        setReferrals([]);
        setTotalEarnings(0);
        if (referralError.message?.includes('429') || referralError.message?.includes('Rate limit')) {
          setError("We're experiencing high traffic. Your referrals will load shortly.");
        }
      }
      
    } catch (error) {
      console.error("Error loading referral data:", error);
      setError("Failed to load referral data. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const copyReferralCode = async () => {
    try {
      await navigator.clipboard.writeText(referralCode);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const shareReferralLink = (platform) => {
    const message = `Hey! I've been using BFLO Contracting for all my home service needs and it's amazing. Use my code ${referralCode} to get $50 off your first service! 🏠✨`;
    const encodedMessage = encodeURIComponent(message);
    
    const urls = {
      email: `mailto:?subject=Get $50 off your first home service&body=${encodedMessage}`,
      sms: `sms:?body=${encodedMessage}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.origin)}&quote=${encodedMessage}`,
      twitter: `https://twitter.com/intent/tweet?text=${encodedMessage}`
    };
    
    if (urls[platform]) {
      window.open(urls[platform], '_blank');
    }
  };

  const sendReferral = async () => {
    if (!newReferralEmail.trim()) return;
    
    try {
      await ReferralEntity.create({
        referrer_id: user.id,
        referred_email: newReferralEmail,
        referral_code: referralCode,
        status: 'pending',
        reward_amount: 50
      });
      
      setNewReferralEmail("");
      await loadData();
    } catch (error) {
      console.error("Error creating referral:", error);
      setError("Failed to send referral. Please try again.");
    }
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-16 bg-gray-200 rounded-xl"></div>
          <div className="grid md:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
              <Gift className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">Refer Friends & Earn</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Share BFLO Contracting with friends and family. You both get $50 off when they complete their first service!
          </p>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 shadow-xl">
            <CardContent className="p-6 text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-3" />
              <p className="text-3xl font-bold mb-1">${totalEarnings}</p>
              <p className="text-green-100">Total Earned</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 shadow-xl">
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 mx-auto mb-3" />
              <p className="text-3xl font-bold mb-1">{referrals.length}</p>
              <p className="text-blue-100">Friends Referred</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 shadow-xl">
            <CardContent className="p-6 text-center">
              <CheckCircle className="w-8 h-8 mx-auto mb-3" />
              <p className="text-3xl font-bold mb-1">{referrals.filter(r => r.status === 'completed').length}</p>
              <p className="text-purple-100">Successful Referrals</p>
            </CardContent>
          </Card>
        </div>

        {/* Referral Code */}
        <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-900">Your Referral Code</CardTitle>
            <p className="text-gray-600">Share this code with friends to get started</p>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex-1 p-4 bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg text-center">
                <p className="text-3xl font-bold text-blue-600 tracking-wider">{referralCode}</p>
              </div>
              <Button onClick={copyReferralCode} className="bg-blue-600 hover:bg-blue-700">
                <Copy className="w-4 h-4 mr-2" />
                {copySuccess ? 'Copied!' : 'Copy'}
              </Button>
            </div>

            {copySuccess && (
              <Alert className="mb-6 bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Referral code copied to clipboard!
                </AlertDescription>
              </Alert>
            )}

            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Share with friends:</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => shareReferralLink('email')}
                  className="flex items-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  Email
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => shareReferralLink('sms')}
                  className="flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  SMS
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => shareReferralLink('facebook')}
                  className="flex items-center gap-2"
                >
                  <Facebook className="w-4 h-4" />
                  Facebook
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => shareReferralLink('twitter')}
                  className="flex items-center gap-2"
                >
                  <Twitter className="w-4 h-4" />
                  Twitter
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Send Direct Invitation */}
        <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Share2 className="w-5 h-5" />
              Send Direct Invitation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input
                placeholder="Enter friend's email address"
                type="email"
                value={newReferralEmail}
                onChange={(e) => setNewReferralEmail(e.target.value)}
                className="flex-1"
              />
              <Button onClick={sendReferral} className="bg-purple-600 hover:bg-purple-700">
                <Mail className="w-4 h-4 mr-2" />
                Send Invite
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Referral History */}
        <Card className="bg-white/60 backdrop-blur border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Referral History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {referrals.length === 0 ? (
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No referrals yet. Start sharing to earn rewards!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {referrals.map((referral) => (
                  <div key={referral.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{referral.referred_email}</p>
                      <p className="text-sm text-gray-500">
                        Invited {new Date(referral.created_date).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge className={
                        referral.status === 'completed' ? 'bg-green-100 text-green-800' :
                        referral.status === 'rewarded' ? 'bg-purple-100 text-purple-800' :
                        'bg-yellow-100 text-yellow-800'
                      }>
                        {referral.status}
                      </Badge>
                      {referral.status === 'rewarded' && (
                        <p className="text-sm font-semibold text-green-600 mt-1">
                          +${referral.reward_amount}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}