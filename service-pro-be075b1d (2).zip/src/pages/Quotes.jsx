
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Quote } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  FileText,
  DollarSign,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  Bot
} from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  pending: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  sent: "bg-primary/10 text-primary border-primary/20",
  viewed: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  accepted: "bg-green-500/10 text-green-400 border-green-500/20",
  rejected: "bg-red-500/10 text-red-400 border-red-500/20",
  expired: "bg-gray-500/10 text-gray-400 border-gray-500/20"
};

export default function Quotes() {
  const [user, setUser] = useState(null);
  const [quotes, setQuotes] = useState([]);
  const [selectedQuote, setSelectedQuote] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
    checkUrlParams();
  }, []);

  const checkUrlParams = () => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'request') {
      // Redirect to AI Quote tool
      window.location.href = createPageUrl("AIQuote");
    }
    if (urlParams.get('id')) {
      const quoteId = urlParams.get('id');
      setSelectedQuote(quoteId);
    }
  };

  const loadData = async () => {
    try {
      const currentUser = await User.me();
      const userQuotes = await Quote.filter({ customer_id: currentUser.id }, "-created_date", 50);

      setUser(currentUser);
      setQuotes(userQuotes);
    } catch (error) {
      console.error("Error loading quotes:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuoteAction = async (quoteId, action) => {
    try {
      await Quote.update(quoteId, { status: action });
      await loadData();
    } catch (error) {
      console.error("Error updating quote:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 lg:p-8">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-16 bg-gray-200 rounded-xl"></div>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                {[1,2,3].map(i => (
                  <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
                ))}
              </div>
              <div className="h-64 bg-gray-200 rounded-xl"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8 bg-background text-foreground min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Quotes</h1>
            <p className="text-muted-foreground">View and manage your service quotes</p>
          </div>
          <Button
            onClick={() => window.location.href = createPageUrl("AIQuote")}
            className="bg-gradient-to-r from-primary to-amber-600 hover:from-amber-500 hover:to-amber-700 text-primary-foreground shadow-lg shadow-primary/20"
          >
            <Bot className="w-5 h-5 mr-2" />
            Get AI Quote
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            {/* Quotes List */}
            <div className="space-y-4">
              {quotes.length === 0 ? (
                <Card className="bg-muted/50 border-border shadow-lg">
                  <CardContent className="p-12 text-center">
                    <FileText className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">No quotes yet</h3>
                    <p className="text-muted-foreground mb-4">Request your first quote to get started</p>
                    <Button
                      onClick={() => window.location.href = createPageUrl("AIQuote")}
                      className="bg-primary hover:bg-primary/90 text-primary-foreground"
                    >
                      <Bot className="w-4 h-4 mr-2" />
                      Get AI Quote
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                quotes.map((quote) => {
                  const isSelected = selectedQuote === quote.id;
                  const isExpired = new Date(quote.valid_until) < new Date();

                  return (
                    <Card
                      key={quote.id}
                      className={`bg-muted/50 border-border shadow-lg hover:shadow-xl transition-all duration-200 cursor-pointer ${
                        isSelected ? 'ring-2 ring-primary shadow-xl shadow-primary/10' : 'hover:border-primary/20'
                      }`}
                      onClick={() => setSelectedQuote(quote.id)}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-1">
                              {quote.title}
                            </h3>
                            <p className="text-muted-foreground text-sm line-clamp-2">
                              {quote.description}
                            </p>
                          </div>

                          <div className="text-right space-y-2">
                            <Badge className={`${statusColors[isExpired ? 'expired' : quote.status]} border`}>
                              {isExpired ? 'expired' : quote.status}
                            </Badge>
                            {quote.notes?.includes('AI-Generated') && (
                              <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20 block">
                                <Bot className="w-3 h-3 mr-1" />
                                AI Quote
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-6 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1 font-semibold text-green-400 text-lg">
                              <DollarSign className="w-5 h-5" />
                              {quote.amount?.toLocaleString()}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              Valid until {format(new Date(quote.valid_until), "MMM d, yyyy")}
                            </span>
                          </div>

                          {quote.status === 'sent' && !isExpired && (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleQuoteAction(quote.id, 'rejected');
                                }}
                                className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                              >
                                <XCircle className="w-4 h-4 mr-1" />
                                Decline
                              </Button>
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleQuoteAction(quote.id, 'accepted');
                                }}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                Accept
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </div>

          <div>
            {/* Quote Details */}
            {selectedQuote ? (
              <Card className="bg-muted/50 border-border shadow-lg sticky top-6">
                <CardHeader>
                  <CardTitle>Quote Details</CardTitle>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const quote = quotes.find(q => q.id === selectedQuote);
                    if (!quote) return null;

                    return (
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-semibold text-foreground mb-2">{quote.title}</h3>
                          <p className="text-muted-foreground text-sm">{quote.description}</p>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="font-medium">Total Amount:</span>
                          <span className="text-2xl font-bold text-green-400">
                            ${quote.amount?.toLocaleString()}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-muted-foreground">Status:</span>
                            <div className="mt-1">
                              <Badge className={`${statusColors[quote.status]} border`}>
                                {quote.status}
                              </Badge>
                            </div>
                          </div>
                          <div>
                            <span className="font-medium text-muted-foreground">Valid Until:</span>
                            <div className="mt-1 text-foreground">
                              {format(new Date(quote.valid_until), "MMM d, yyyy")}
                            </div>
                          </div>
                        </div>

                        {quote.line_items && quote.line_items.length > 0 && (
                          <div>
                            <h4 className="font-semibold mb-3">Line Items:</h4>
                            <div className="space-y-2">
                              {quote.line_items.map((item, index) => (
                                <div key={index} className="flex justify-between text-sm p-2 bg-muted/50 rounded">
                                  <div>
                                    <span className="font-medium text-foreground">{item.description}</span>
                                    {item.quantity && item.rate && (
                                      <div className="text-muted-foreground">
                                        {item.quantity} × ${item.rate}
                                      </div>
                                    )}
                                  </div>
                                  <span className="font-semibold text-foreground">${item.amount}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {quote.notes && (
                          <div>
                            <h4 className="font-semibold mb-2">Notes:</h4>
                            <div className="text-sm text-muted-foreground bg-muted/50 p-3 rounded">
                              {quote.notes.split('\n').map((line, index) => (
                                <div key={index}>{line}</div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-muted/50 border-border shadow-lg">
                <CardContent className="p-8 text-center">
                  <Eye className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                  <h3 className="font-semibold text-foreground mb-2">Select a quote</h3>
                  <p className="text-muted-foreground text-sm">Choose a quote from the list to view details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
